USE retail_customer_intelligence;

-- 1. Total customers and recorded purchase amount (not transaction count).
SELECT COUNT(DISTINCT customer_id) AS total_customers,
       ROUND(SUM(purchase_amount_usd), 2) AS recorded_purchase_amount
FROM customer_data;

-- 2. Revenue by category.
SELECT category, COUNT(*) AS customers, ROUND(SUM(purchase_amount_usd),2) AS revenue
FROM customer_data GROUP BY category ORDER BY revenue DESC;

-- 3. Revenue by season.
SELECT season, ROUND(SUM(purchase_amount_usd),2) AS revenue
FROM customer_data GROUP BY season ORDER BY revenue DESC;

-- 4. Average spend by subscription status; descriptive, not causal.
SELECT subscription_status, COUNT(*) AS customers, ROUND(AVG(purchase_amount_usd),2) AS avg_spend
FROM customer_data GROUP BY subscription_status;

-- 5. Payment method distribution and recorded purchase amount.
SELECT payment_method, COUNT(*) AS customers, ROUND(SUM(purchase_amount_usd),2) AS revenue
FROM customer_data GROUP BY payment_method ORDER BY revenue DESC;

-- 6. Customer segment contribution. Requires customer_segments to be loaded.
SELECT s.Customer_Segment, COUNT(*) AS customers, ROUND(SUM(c.purchase_amount_usd),2) AS revenue,
       ROUND(100 * SUM(c.purchase_amount_usd) / totals.total_revenue, 1) AS revenue_pct
FROM customer_data c JOIN customer_segments s USING (customer_id)
CROSS JOIN (SELECT SUM(purchase_amount_usd) AS total_revenue FROM customer_data) totals
GROUP BY s.Customer_Segment, totals.total_revenue ORDER BY revenue DESC;

-- 7. Top 3 items by recorded revenue within each category (MySQL 8+ window function).
WITH ranked_items AS (
  SELECT category, item_purchased, SUM(purchase_amount_usd) AS revenue,
         DENSE_RANK() OVER (PARTITION BY category ORDER BY SUM(purchase_amount_usd) DESC) AS item_rank
  FROM customer_data GROUP BY category, item_purchased
) SELECT category, item_purchased, revenue, item_rank
FROM ranked_items WHERE item_rank <= 3 ORDER BY category, item_rank;

-- 8. Locations with revenue above the average location-level revenue.
SELECT location, SUM(purchase_amount_usd) AS revenue
FROM customer_data GROUP BY location
HAVING SUM(purchase_amount_usd) > (
  SELECT AVG(location_revenue) FROM (
    SELECT SUM(purchase_amount_usd) AS location_revenue FROM customer_data GROUP BY location
  ) AS location_totals
) ORDER BY revenue DESC;

-- 9. Check source/customer grain: expected one row per customer.
SELECT customer_id, COUNT(*) AS row_count FROM customer_data
GROUP BY customer_id HAVING COUNT(*) > 1;

-- 10. Data reconciliation against notebook total. Expected 233081 for supplied sample.
SELECT ROUND(SUM(purchase_amount_usd),2) AS total_revenue FROM customer_data;

-- 11. KPI verification: live value computed from the tables vs the registry's expected value.
--     KPI IDs, names and formulas come from kpi_registry (same IDs shown on the Power BI cards).
SELECT r.kpi_id, r.kpi_name, r.calculation_formula, r.data_source,
       ROUND(k.live_value, 2) AS live_value, r.expected_value,
       CASE WHEN ROUND(k.live_value, 2) = r.expected_value THEN 'PASS' ELSE 'FAIL' END AS status
FROM kpi_registry r
JOIN (
  SELECT 'KPI-001' AS kpi_id, COUNT(DISTINCT customer_id) AS live_value FROM customer_data
  UNION ALL SELECT 'KPI-002', SUM(purchase_amount_usd) FROM customer_data
  UNION ALL SELECT 'KPI-003', AVG(purchase_amount_usd) FROM customer_data
  UNION ALL SELECT 'KPI-004', AVG(review_rating) FROM customer_data
  UNION ALL SELECT 'KPI-005', COUNT(DISTINCT customer_id) FROM customer_data WHERE subscription_status = 'Yes'
) k ON k.kpi_id = r.kpi_id
ORDER BY r.kpi_id;

-- 12. Average Purchase Value: transaction vs customer-level definitions.
--     The source has ONE ROW PER CUSTOMER, so both definitions are identical (59.76).
SELECT ROUND(SUM(purchase_amount_usd) / COUNT(*), 2)                AS avg_per_record,
       ROUND(SUM(purchase_amount_usd) / COUNT(DISTINCT customer_id), 2) AS avg_per_customer
FROM customer_data;

-- 13. Customers and revenue by age group (six bands; same grouping as the dashboard).
SELECT age_group, COUNT(*) AS customers, ROUND(SUM(purchase_amount_usd), 2) AS revenue
FROM customer_data GROUP BY age_group ORDER BY age_group;
