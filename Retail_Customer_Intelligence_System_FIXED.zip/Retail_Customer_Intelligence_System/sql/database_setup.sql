-- =============================================================================
-- Retail Customer Intelligence System: MySQL 8.0+ database setup
-- =============================================================================
-- Reproducible: running this script on an empty OR previously-used server always
-- yields the same schema, with no manual schema changes.
--
--   mysql -u <user> -p < sql/database_setup.sql      (schema + KPI registry)
--   python scripts/load_mysql.py                      (schema + registry + data)
--
-- WARNING: this script DROPS and recreates the three project tables below
-- (customer_segments, customer_data, kpi_registry) inside
-- retail_customer_intelligence. Other tables and databases are never touched.
--
-- Creation order matters because of the foreign key:
--   1) customer_data      (parent)   <- load cleaned_customer_data.csv FIRST
--   2) customer_segments  (child, FK -> customer_data.customer_id)
--   3) kpi_registry       (independent metadata, no FK)
-- Drop order is the reverse (child first).
-- =============================================================================
CREATE DATABASE IF NOT EXISTS retail_customer_intelligence
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE retail_customer_intelligence;

DROP TABLE IF EXISTS customer_segments;
DROP TABLE IF EXISTS customer_data;
DROP TABLE IF EXISTS kpi_registry;

-- 1) Parent table. One row per customer (NOT transaction-level data).
CREATE TABLE customer_data (
  customer_id            INT           NOT NULL,
  age                    INT           NOT NULL,
  gender                 VARCHAR(20)   NOT NULL,
  item_purchased         VARCHAR(80)   NOT NULL,
  category               VARCHAR(40)   NOT NULL,
  purchase_amount_usd    DECIMAL(10,2) NOT NULL,
  location               VARCHAR(80)   NOT NULL,
  size                   VARCHAR(10)   NOT NULL,
  color                  VARCHAR(40)   NOT NULL,
  season                 VARCHAR(20)   NOT NULL,
  review_rating          DECIMAL(3,1)  NOT NULL,
  subscription_status    VARCHAR(10)   NOT NULL,
  shipping_type          VARCHAR(40)   NOT NULL,
  discount_applied       VARCHAR(10)   NOT NULL,
  previous_purchases     INT           NOT NULL,
  payment_method         VARCHAR(40)   NOT NULL,
  frequency_of_purchases VARCHAR(40)   NOT NULL,
  rating_imputed         TINYINT       NOT NULL DEFAULT 0,
  age_group              VARCHAR(10)   NOT NULL,
  spending_category      VARCHAR(10)   NOT NULL,
  rating_category        VARCHAR(15)   NOT NULL,
  loyalty_category       VARCHAR(15)   NOT NULL,
  discount_flag          TINYINT       NOT NULL,
  subscription_flag      TINYINT       NOT NULL,
  PRIMARY KEY (customer_id),
  CONSTRAINT chk_cd_age          CHECK (age BETWEEN 0 AND 120),
  CONSTRAINT chk_cd_amount       CHECK (purchase_amount_usd >= 0),
  CONSTRAINT chk_cd_rating       CHECK (review_rating BETWEEN 0 AND 5),
  CONSTRAINT chk_cd_subscription CHECK (subscription_status IN ('Yes','No')),
  CONSTRAINT chk_cd_age_group    CHECK (age_group IN ('18-24','25-34','35-44','45-54','55-64','65+')),
  CONSTRAINT chk_cd_flags        CHECK (rating_imputed IN (0,1) AND discount_flag IN (0,1) AND subscription_flag IN (0,1)),
  INDEX idx_cd_category (category),
  INDEX idx_cd_age_group (age_group)
) ENGINE=InnoDB;

-- 2) Child table: LFM (Loyalty-Frequency-Monetary) segmentation, 1:1 with customer_data.
CREATE TABLE customer_segments (
  customer_id            INT           NOT NULL,
  previous_purchases     INT           NOT NULL,
  purchase_amount_usd    DECIMAL(10,2) NOT NULL,
  frequency_of_purchases VARCHAR(40)   NOT NULL,
  L_Score                TINYINT       NOT NULL,
  F_Score                TINYINT       NOT NULL,
  M_Score                TINYINT       NOT NULL,
  LFM_Score              TINYINT       NOT NULL,
  Customer_Segment       VARCHAR(40)   NOT NULL,
  PRIMARY KEY (customer_id),
  CONSTRAINT fk_segments_customer FOREIGN KEY (customer_id) REFERENCES customer_data (customer_id),
  CONSTRAINT chk_seg_scores CHECK (L_Score BETWEEN 1 AND 5 AND F_Score BETWEEN 1 AND 5 AND M_Score BETWEEN 1 AND 5
                                   AND LFM_Score = L_Score + F_Score + M_Score),
  INDEX idx_seg_segment (Customer_Segment)
) ENGINE=InnoDB;

-- 3) KPI registry: the single list of KPI IDs used by the database, notebook,
--    documentation AND the Power BI dashboard cards. No relationship to customer data.
CREATE TABLE kpi_registry (
  kpi_id              VARCHAR(10)    NOT NULL,
  kpi_name            VARCHAR(100)   NOT NULL,
  description         VARCHAR(500)   NOT NULL,
  calculation_formula VARCHAR(500)   NOT NULL,
  dax_formula         VARCHAR(500)   NOT NULL,
  data_source         VARCHAR(200)   NOT NULL,
  expected_value      DECIMAL(12,2)  NOT NULL,
  unit                VARCHAR(40)    NOT NULL,
  PRIMARY KEY (kpi_id),
  UNIQUE KEY uq_kpi_name (kpi_name),
  CONSTRAINT chk_kpi_id_format CHECK (kpi_id REGEXP '^KPI-[0-9]{3}$')
) ENGINE=InnoDB;

INSERT INTO kpi_registry
  (kpi_id, kpi_name, description, calculation_formula, dax_formula, data_source, expected_value, unit)
VALUES
 ('KPI-001', 'Total Customers',
  'Number of distinct customers in the cleaned customer dataset (one row per customer).',
  'COUNT(DISTINCT customer_data.customer_id)',
  'DISTINCTCOUNT(customer_data[customer_id])',
  'customer_data.customer_id', 3900, 'customers'),
 ('KPI-002', 'Total Revenue',
  'Sum of the recorded purchase amount (USD) over all customers. One purchase value per customer; not transaction-level history.',
  'SUM(customer_data.purchase_amount_usd)',
  'SUM(customer_data[purchase_amount_usd])',
  'customer_data.purchase_amount_usd', 233081, 'USD'),
 ('KPI-003', 'Average Purchase Value',
  'Average purchase_amount_usd per customer record. The data has one row per customer, so this equals average customer spend and average value per recorded purchase.',
  'AVG(customer_data.purchase_amount_usd)',
  'AVERAGE(customer_data[purchase_amount_usd])',
  'customer_data.purchase_amount_usd', 59.76, 'USD per customer'),
 ('KPI-004', 'Average Review Rating',
  'Mean review rating (scale 0 to 5) after documented category-median imputation of 37 missing ratings.',
  'AVG(customer_data.review_rating)',
  'AVERAGE(customer_data[review_rating])',
  'customer_data.review_rating', 3.75, 'rating out of 5'),
 ('KPI-005', 'Customers With Subscription',
  'Number of distinct customers whose subscription_status is Yes.',
  'COUNT(DISTINCT customer_id) WHERE subscription_status = ''Yes''',
  'CALCULATE(DISTINCTCOUNT(customer_data[customer_id]), customer_data[subscription_status] = "Yes")',
  'customer_data.customer_id, customer_data.subscription_status', 1053, 'customers');

-- Data load (done by scripts/load_mysql.py, or the Workbench import wizard) must
-- follow FK order: customer_data (cleaned_customer_data.csv) first, then
-- customer_segments (customer_lfm_segmentation.csv).
