# Manual Tasks Checklist & End-to-End Operational Guide

This document covers:
1. **Part 1 — Manual Tasks Remaining**: Step-by-step instructions for the tasks that require interactive GUI access (Power BI Desktop) or your local MySQL 8+ credentials.
2. **Part 2 — End-to-End Operational Guide**: How to set up, run, verify, and maintain the entire **Retail Customer Intelligence System** from raw data to final dashboard.

---

## Part 1: Manual Tasks Remaining

All code, data, notebook, SQL, PowerPoint diagram, diagram screenshot, and documentation fixes from the review PDF have been applied. Only the following environment- and GUI-dependent tasks need to be completed manually on your machine.

### Task 1: Load the Regenerated CSVs into MySQL 8+ (Problems 2 & 6, TC-10 to TC-12)

Because `customer_segments` has a foreign key (`fk_segments_customer`) referencing `customer_data(customer_id)`, **`customer_data` must be loaded first, and `customer_segments` second**.

#### Option A: Using MySQL Workbench (GUI)
1. Open **MySQL Workbench** and connect to your local `MySQL80` instance.
2. Open and execute [`sql/database_setup.sql`](../sql/database_setup.sql) to create the `retail_customer_intelligence` schema and the two tables (`customer_data` and `customer_segments`).
   - *Note:* If the tables already exist from an earlier run, clear them in reverse foreign-key order before importing:
     ```sql
     USE retail_customer_intelligence;
     DELETE FROM customer_segments;
     DELETE FROM customer_data;
     ```
3. In the **Schemas** panel, right-click `customer_data` $\rightarrow$ **Table Data Import Wizard**:
   - Select [`data/cleaned_customer_data.csv`](../data/cleaned_customer_data.csv).
   - Choose **Use existing table: `retail_customer_intelligence.customer_data`**.
   - Confirm all 24 columns map 1:1 and complete the import (3,900 rows).
4. Right-click `customer_segments` $\rightarrow$ **Table Data Import Wizard**:
   - Select [`data/customer_lfm_segmentation.csv`](../data/customer_lfm_segmentation.csv).
   - Choose **Use existing table: `retail_customer_intelligence.customer_segments`**.
   - Confirm all 9 columns map 1:1 and complete the import (3,900 rows).

#### Option B: Using the Python SQLAlchemy Loader (CLI)
Run the following in PowerShell from the project root (substituting your MySQL username and password):

```powershell
$env:MYSQL_USER = "root"
$env:MYSQL_PASSWORD = "your_mysql_password"
$env:MYSQL_HOST = "localhost"
$env:MYSQL_DATABASE = "retail_customer_intelligence"

& "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe" -u root -p"$env:MYSQL_PASSWORD" < sql\database_setup.sql

python -c "
import os, pandas as pd
from sqlalchemy import create_engine, text

engine = create_engine(
    f'mysql+pymysql://{os.environ[\"MYSQL_USER\"]}:{os.environ[\"MYSQL_PASSWORD\"]}@'
    f'{os.getenv(\"MYSQL_HOST\", \"localhost\")}/{os.getenv(\"MYSQL_DATABASE\", \"retail_customer_intelligence\")}'
)
with engine.begin() as conn:
    conn.execute(text('DELETE FROM customer_segments'))
    conn.execute(text('DELETE FROM customer_data'))

clean = pd.read_csv('data/cleaned_customer_data.csv')
seg = pd.read_csv('data/customer_lfm_segmentation.csv')

clean.to_sql('customer_data', engine, if_exists='append', index=False)
seg.to_sql('customer_segments', engine, if_exists='append', index=False)
print('Loaded customer_data:', len(clean), 'rows; customer_segments:', len(seg), 'rows.')
"
```

#### Verify MySQL Queries
Run [`sql/customer_analysis.sql`](../sql/customer_analysis.sql) in MySQL Workbench (or via CLI) and verify:
- **Query 1 & Query 10:** `total_customers = 3900`, `recorded_purchase_amount = 233081.00`
- **Query 6 (Segment contribution):**
  - `Potential Loyalists`: **1,734** customers | **$103,287.00** | **44.3%**
  - `Loyal`: **795** customers | **$58,890.00** | **25.3%**
  - `Needs Attention`: **795** customers | **$37,395.00** | **16.0%**
  - `Champions`: **274** customers | **$23,216.00** | **10.0%**
  - `Low Engagement`: **302** customers | **$10,293.00** | **4.4%**
- **Query 9 (Grain check):** Returns `0 rows` (confirming unique `customer_id`).

---

### Task 2: Fix and Refresh the Power BI File in Power BI Desktop (Problems 1 & 4, TC-13 & TC-14)

The binary [`.pbix` file](../powerbi/customer_behavior_dashboard.pbix) cannot be edited safely outside **Power BI Desktop**. Follow these exact steps in Power BI Desktop:

1. **Open and Save a Working Copy**
   - Launch **Power BI Desktop** and open [`powerbi/customer_behavior_dashboard.pbix`](../powerbi/customer_behavior_dashboard.pbix).
   - Save a copy as `powerbi/customer_behavior_dashboard_FIXED.pbix` (and once verified, also save over `powerbi/customer_behavior_dashboard.pbix` so the main project file is up to date).

2. **Repoint the Main Data Source (`public customer` $\rightarrow$ `customer_data`)**
   - Click **Home $\rightarrow$ Transform data $\rightarrow$ Transform data** to open Power Query Editor.
   - Select the existing `public customer` query in the left pane and rename it to **`customer_data`**.
   - In **Applied Steps**, click the gear icon next to **Source** (or open **Advanced Editor**) and point it to either:
     - Your local MySQL database `retail_customer_intelligence` table `customer_data`, **or**
     - Local CSV file [`data/cleaned_customer_data.csv`](../data/cleaned_customer_data.csv) (via **New Source $\rightarrow$ Text/CSV**).
   - Ensure column data types match (`customer_id` Whole Number, `purchase_amount_usd` Decimal/Whole Number, `review_rating` Decimal Number).

3. **Load the LFM Segmentation Table (`customer_segments`)**
   - Still in Power Query Editor (or via **Home $\rightarrow$ Get data**), load [`data/customer_lfm_segmentation.csv`](../data/customer_lfm_segmentation.csv) (or the MySQL `customer_segments` table) and name the table **`customer_segments`**.
   - Click **Close & Apply**.
   - Go to **Model view** (left sidebar) and drag `customer_data[customer_id]` onto `customer_segments[customer_id]` to create a **One-to-One (1:1)** relationship.

4. **Add the DAX Measures**
   - In **Report view**, select `customer_data` in the **Data** pane and click **Modeling $\rightarrow$ New measure** to create each measure from [`powerbi/KPI_Measures.dax`](../powerbi/KPI_Measures.dax):
     ```dax
     Total Customers = DISTINCTCOUNT(customer_data[customer_id])

     Total Revenue = SUM(customer_data[purchase_amount_usd])

     Average Purchase Value = AVERAGE(customer_data[purchase_amount_usd])

     Average Review Rating = AVERAGE(customer_data[review_rating])

     Customers With Subscription =
     CALCULATE(
         DISTINCTCOUNT(customer_data[customer_id]),
         customer_data[subscription_status] = "Yes"
     )
     ```
   - Format `Total Revenue` and `Average Purchase Value` as **Currency ($ USD)**, `Total Customers` with a thousands separator (`3,900`), and `Average Review Rating` to **2 decimal places** (`3.75`).

5. **Remove the Hidden `Accessories` Filter & Rebind KPI Cards**
   - Select each KPI card visual on the canvas and open the **Filters** pane.
   - **Remove the `category is Accessories` filter** from the visual-level filters.
   - Bind the KPI cards to the new measures:
     - **Total Customers** (`3,900`)
     - **Total Revenue** (`$233,081`)
     - **Average Purchase Value** (`$59.76`)
     - **Average Review Rating** (`3.75`)

6. **Rebind Revenue and Age Group Visuals**
   - Select **"Revenue by Category"** and **"Revenue by Age Group"**: replace the broken `purchase_amount` field with `purchase_amount_usd` (or `[Total Revenue]`).
   - Select **"Revenue by Age Group"** and **"Sales by Age Group"**: replace the old 4-band age field with `customer_data[age_group]` (which has the 6 corrected bands: `18-24`, `25-34`, `35-44`, `45-54`, `55-64`, `65+`).

7. **Rename Mislabelled "Sales" Customer-Count Charts (Problem 4)**
   - Select the **"Sales by Category"** visual $\rightarrow$ **Format visual $\rightarrow$ General $\rightarrow$ Title** $\rightarrow$ change title text to **`Customers by Category`**.
   - Select the **"Sales by Age Group"** visual $\rightarrow$ **Format visual $\rightarrow$ General $\rightarrow$ Title** $\rightarrow$ change title text to **`Customers by Age Group`**.

8. **Add an LFM Customer Segment Visual**
   - Add a bar/column chart (or combo chart) using `customer_segments[Customer_Segment]` on the axis and `[Total Customers]` (and/or `[Total Revenue]`) as values so the LFM segmentation result is visible on the dashboard.

9. **Refresh, Validate, Save, and Reopen**
   - Click **Home $\rightarrow$ Refresh**.
   - Confirm With No Slicers Selected:
     - **Total Customers** = `3,900`
     - **Total Revenue** = `$233,081`
     - **Average Purchase Value** = `$59.76`
     - **Average Review Rating** = `3.75`
   - Save the file, close Power BI Desktop, and reopen the `.pbix` file to confirm it loads with zero errors.

---

### Task 3: Retake `screenshots/dashboard.png` (Problems 1, 3 & 4)
1. With the updated dashboard open in Power BI Desktop (and all slicers cleared), take a clean screenshot of the report canvas.
2. Save it over [`screenshots/dashboard.png`](../screenshots/dashboard.png).

---

### Task 4: Update Final Status in `testing/Test_Cases.docx` (Checklist Item 8)
1. Open [`testing/Test_Cases.docx`](../testing/Test_Cases.docx) in Microsoft Word.
2. Under the **Execution record** section at the bottom:
   - Change **TC-10, TC-11, and TC-12** from `VERIFIED ON SQLITE 3 / NOT VERIFIED ON LIVE MYSQL 8+` to `PASS (Verified on MySQL 8.0)` with your execution date.
   - Change **TC-13 and TC-14** from `NOT VERIFIED (FAILS ON CURRENT PBIX)` to `PASS (Verified in Power BI Desktop)` after saving the updated `.pbix` and retaking `dashboard.png`.

---

## Part 2: End-to-End Operational Guide

### 1. Architecture & Data Flow
```text
data/customer_shopping_data.csv (Raw input: 3,900 rows × 18 columns)
        │
        ▼
python/customer_analysis.ipynb (Cleaning, feature engineering, tie-safe LFM scoring, assertions)
        │
        ├──► data/cleaned_customer_data.csv (3,900 rows × 24 columns)
        │           │
        │           ▼ (Load FIRST)
        │    MySQL: customer_data (PK: customer_id)
        │           ▲
        └──► data/customer_lfm_segmentation.csv (3,900 rows × 9 columns)
                    │
                    ▼ (Load SECOND — FK references customer_data.customer_id)
             MySQL: customer_segments (PK/FK: customer_id)
                    │
                    ▼
             sql/customer_analysis.sql (10 analytical & reconciliation queries)
                    │
                    ▼
             powerbi/customer_behavior_dashboard.pbix (KPIs, Category/Age/Segment visuals)
```

### 2. Environment Setup
1. **Prerequisites:**
   - Python 3.10+ (verified on Python 3.13.7)
   - MySQL Server 8.0+ & MySQL Workbench
   - Microsoft Power BI Desktop
2. **Virtual Environment & Packages:**
   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   ```

### 3. Running the Python Pipeline (`python/customer_analysis.ipynb`)
1. Start Jupyter from the project root:
   ```powershell
   jupyter notebook python/customer_analysis.ipynb
   ```
2. Run all cells from top to bottom (**Kernel $\rightarrow$ Restart & Run All**):
   - **Section 1–2 (Load & Clean):** Validates `3,900 × 18` shape and unique `Customer ID`, converts `Review Rating` to numeric, flags the 37 missing ratings in `rating_imputed`, imputes missing ratings using each `Category`'s median rating, and normalizes column names to `snake_case`.
   - **Section 3 (Feature Engineering):**
     - `age_group`: `18-24`, `25-34`, `35-44`, `45-54`, `55-64`, `65+`
     - `spending_category`: `Low` (0–30), `Medium` (31–60), `High` (61–100)
     - `rating_category`: `Low` ($\le 3.0$), `Good` (3.1–4.0), `Excellent` (4.1–5.0)
     - `loyalty_category`: `New` (0–15), `Regular` (16–30), `Loyal` (31–50)
     - `discount_flag` & `subscription_flag`: binary `1`/`0`
     - Drops `promo_code_used` after verifying it is identical to `discount_applied`.
   - **Section 4 (EDA):** Outputs total revenue (`$233,081`), average purchase (`$59.76`), and plots revenue by category, revenue by season, and customers by age group.
   - **Section 5 (Tie-Safe LFM Segmentation):**
     - Maps `frequency_of_purchases` to `F_Score` (`Weekly: 5`, `Fortnightly: 4`, `Bi-Weekly: 4` [every two weeks], `Monthly: 3`, `Quarterly: 2`, `Every 3 Months: 2`, `Annually: 1`).
     - Computes `L_Score` (`previous_purchases`) and `M_Score` (`purchase_amount_usd`) using tie-safe percentile ranks (`rank(method="average", pct=True)`), ensuring tied values always receive the same score.
     - Sums `LFM_Score = L_Score + F_Score + M_Score` (range 3–15) and assigns segments:
       - `>= 13`: **Champions** (274 customers)
       - `11–12`: **Loyal** (795 customers)
       - `8–10`: **Potential Loyalists** (1,734 customers)
       - `6–7`: **Needs Attention** (795 customers)
       - `< 6`: **Low Engagement** (302 customers)
   - **Section 6 (Export):** Writes `data/cleaned_customer_data.csv` and `data/customer_lfm_segmentation.csv`.
   - **Section 7 (Validation Tests):** Runs 11 automated assertions covering row count, uniqueness, zero nulls, tie-safe L/M score mapping, segment count, customer ID set equality, and total revenue (`$233,081`).

### 4. Running the SQL Pipeline (`sql/`)
1. Execute [`sql/database_setup.sql`](../sql/database_setup.sql) to initialize the database and tables.
2. Import `cleaned_customer_data.csv` into `customer_data` **first**, then `customer_lfm_segmentation.csv` into `customer_segments` **second**.
3. Execute [`sql/customer_analysis.sql`](../sql/customer_analysis.sql) to run the 10 business and validation queries:
   - **Q1:** Total customers & recorded purchase amount
   - **Q2:** Customers & revenue by category
   - **Q3:** Revenue by season
   - **Q4:** Average spend by subscription status
   - **Q5:** Payment method distribution & revenue
   - **Q6:** LFM customer segment contribution (customers, revenue, revenue %)
   - **Q7:** Top 3 items by revenue within each category (`DENSE_RANK() OVER (...)`)
   - **Q8:** Locations with revenue above average location revenue
   - **Q9:** Duplicate `customer_id` grain check (expects 0 rows)
   - **Q10:** Total revenue reconciliation check (expects `233081.00`)

### 5. Key Reference Numbers for Verification
Use these numbers whenever verifying exports, SQL queries, or Power BI visuals:

| Metric | Expected Value |
| :--- | :--- |
| **Total Customers** | `3,900` |
| **Total Revenue** | `$233,081.00` |
| **Average Purchase Value** | `$59.76` |
| **Average Review Rating (after imputation)** | `3.75` (37 imputed rows) |
| **Category Revenue** | Clothing `$104,264` (1,737) · Accessories `$74,200` (1,240) · Footwear `$36,093` (599) · Outerwear `$18,524` (324) |
| **Season Revenue** | Fall `$60,018` · Spring `$58,679` · Winter `$58,607` · Summer `$55,777` |
| **LFM Segments (Customers / Revenue / Share)** | Potential Loyalists `1,734` (`$103,287` / `44.31%`) · Loyal `795` (`$58,890` / `25.27%`) · Needs Attention `795` (`$37,395` / `16.04%`) ·Champions `274` (`$23,216` / `9.96%`) · Low Engagement `302` (`$10,293` / `4.42%`) |
