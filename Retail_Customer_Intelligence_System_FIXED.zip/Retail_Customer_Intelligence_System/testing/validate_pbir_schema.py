#!/usr/bin/env python3
"""Validate every generated PBIR/TMDL-adjacent JSON file against Microsoft's published schemas
(https://github.com/microsoft/json-schemas). The schema repository is downloaded once to
testing/.cache/ (needs internet on first run). Requires: pip install jsonschema referencing
"""
from __future__ import annotations

import io
import json
import urllib.request
import zipfile
from pathlib import Path

from jsonschema import Draft7Validator
from referencing import Registry, Resource
from referencing.jsonschema import DRAFT7

ROOT = Path(__file__).resolve().parents[1]
CACHE = ROOT / "testing" / ".cache"
SCHEMA_ROOT = CACHE / "json-schemas-main"
BASE = "https://developer.microsoft.com/json-schemas/"
ZIP_URL = "https://codeload.github.com/microsoft/json-schemas/zip/refs/heads/main"


def ensure_schemas() -> Path:
    if not SCHEMA_ROOT.exists():
        CACHE.mkdir(parents=True, exist_ok=True)
        with urllib.request.urlopen(ZIP_URL, timeout=120) as r:
            zipfile.ZipFile(io.BytesIO(r.read())).extractall(CACHE)
    return SCHEMA_ROOT


def run() -> tuple[bool, str]:
    root = ensure_schemas()

    def retrieve(uri):
        if uri.startswith(BASE):
            return Resource.from_contents(json.loads((root / uri[len(BASE):]).read_text(encoding="utf-8")),
                                          default_specification=DRAFT7)
        raise LookupError(uri)

    registry = Registry(retrieve=retrieve)
    pb = ROOT / "powerbi"
    files = [p for pat in ("*.json", "*.pbir", "*.pbism", "*.pbip") for p in pb.rglob(pat)
             if "StaticResources" not in p.parts and "_theme" not in p.parts]
    failures, count = [], 0
    for p in sorted(files):
        doc = json.loads(p.read_text(encoding="utf-8"))
        uri = doc.get("$schema", "")
        if not uri.startswith(BASE):
            continue
        schema = json.loads((root / uri[len(BASE):]).read_text(encoding="utf-8"))
        errs = sorted(Draft7Validator(schema, registry=registry).iter_errors(doc), key=lambda e: list(e.path))
        count += 1
        for e in errs[:3]:
            failures.append(f"{p.relative_to(pb)}: {list(e.path)} {e.message[:160]}")
    if failures:
        return False, f"{len(failures)} schema errors in {count} files: " + " | ".join(failures[:5])
    return True, f"{count} JSON files valid against Microsoft schemas"


if __name__ == "__main__":
    ok, msg = run()
    print(("PASS: " if ok else "FAIL: ") + msg)
    raise SystemExit(0 if ok else 1)
