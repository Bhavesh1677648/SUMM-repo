# Automated test results

- Run: 2026-10-28 03:46 | Python 3.12.3 | pandas 3.0.2 | numpy 2.4.4 | MySQL server version: 8.0.46-0ubuntu0.24.04.4

| Step | Result | Detail |
|---|---|---|
| CSV validation (scripts/validate_data.py) | PASS | 15 checks passed |
| Notebook executed start to finish (all assertions + KPI-ID checks) | PASS | 10 code cells, 0 errors, regenerated CSVs identical to committed: True |
| Power BI project model/visual checks (testing/test_dashboard_model.py) | PASS | 24/24 dashboard-model checks passed |
| MySQL integration (testing/test_mysql_integration.py) | PASS | 14/14 MySQL integration checks passed |

## Power BI project checks

| ID | Result | Check |
|---|---|---|
| PBI-01 | PASS | PBIR/TMDL JSON validates against Microsoft's published schemas |
| PBI-02 | PASS | Model has exactly customer_data, customer_segments, kpi_registry (no PostgreSQL 'public customer') |
| PBI-03 | PASS | Every TMDL column name/sourceColumn equals the CSV header, in order (column references up to date) |
| PBI-04 | PASS | Column data types are compatible with the CSV values (no nulls, ints are ints, numbers are numeric) |
| PBI-05 | PASS | customer_segments->customer_data is one-to-one on customer_id, keys unique, same ID sets, registry not related |
| PBI-06 | PASS | Every field used by every visual resolves to an existing model column or measure |
| PBI-07 | PASS | Revenue uses customer_data[purchase_amount_usd]; no visual binds the duplicate hidden segment columns |
| PBI-08 | PASS | No outdated names remain (public customer, purchase_amount without _usd, old age labels, Number of Customers, 'Sales by') |
| PBI-09 | PASS | No hard-coded/saved filters anywhere (no Accessories, filterConfig, Where clauses, saved slicer selections) |
| PBI-10 | PASS | Five KPI cards, one per ID, titles read 'KPI-00X | Name' exactly as in kpi_registry |
| PBI-11 | PASS | Measure DAX in the model equals kpi_registry.dax_formula for all five KPIs |
| PBI-12 | PASS | Unfiltered KPI cards evaluate to the required baseline values (evaluating the DAX text from the model) |
| PBI-13 | PASS | Measure number formats display the expected text (3,900 / $233,081 / $59.76 / 3.75 / 1,053) |
| PBI-14 | PASS | Average Purchase Value: per-record equals per-customer (one row per customer), so the definition is unambiguous |
| PBI-15 | PASS | KPI registry table visual shows ID, name, formula, data source, description from kpi_registry |
| PBI-16 | PASS | Age-group charts use age_group with exactly the six correct bands (no old four labels) |
| PBI-17 | PASS | LFM segmentation visuals exist and reproduce the verified segment counts and revenue |
| PBI-18 | PASS | Chart titles match their aggregation (Revenue->Total Revenue, Customers->Total Customers); no 'Sales by' |
| PBI-19 | PASS | Every chart reconciles to its KPI total (catches wrong aggregation such as Sum(customer_id)) |
| PBI-20 | PASS | Slicers: for every slicer member, KPI cards equal an independent pandas calculation; members partition the total |
| PBI-21 | PASS | Slicer behaviour on charts: filtering one category/segment/age group only changes the matching bars |
| PBI-22 | PASS | KPI Registry table is unaffected by slicers (no relationship) while KPI cards respond to them |
| PBI-23 | PASS | Layout: every visual lies inside the 1500x940 page and data visuals do not overlap |
| PBI-24 | PASS | DataFolder parameter exists and every table's CSV file is present in data/ |

## MySQL checks

| ID | Result | Check |
|---|---|---|
| SQL-01 | PASS | database_setup.sql runs on an empty database with no errors; tables come out in FK-safe order |
| SQL-02 | PASS | Importing segments BEFORE customers is rejected by the foreign key (proves the required load order) |
| SQL-03 | PASS | load_mysql.py loads customer_data first, then customer_segments, then verifies (exit code 0) |
| SQL-04 | PASS | Row counts: 3,900 customers, 3,900 segments, 5 KPI registry rows; no orphans |
| SQL-05 | PASS | Primary keys: customer_data(customer_id), customer_segments(customer_id), kpi_registry(kpi_id) |
| SQL-06 | PASS | Foreign key: customer_segments.customer_id -> customer_data.customer_id (and delete of a parent with a child is blocked) |
| SQL-07 | PASS | Column types: every column of the three tables has the expected MySQL type/precision |
| SQL-08 | PASS | CHECK constraints enforce valid data (bad subscription_status, rating, age_group, LFM score, KPI ID are rejected) |
| SQL-09 | PASS | Re-running the full setup+load on a populated database is idempotent (no manual schema changes needed) |
| SQL-10 | PASS | Stale/incompatible old tables are replaced cleanly (old-schema table is dropped and recreated by the loader) |
| SQL-11 | PASS | customer_analysis.sql: all queries execute without error on MySQL and return rows |
| SQL-12 | PASS | KPI query results: five KPI IDs, live values equal the required baseline, status PASS |
| SQL-13 | PASS | Analytical results match pandas (revenue by category, age group, segment) so MySQL and Power BI agree |
| SQL-14 | PASS | kpi_registry table content equals data/kpi_registry.csv (dashboard and database use the same KPI IDs) |

## Not covered by automation (requires Power BI Desktop)

Opening the PBIP, Refresh, and capturing real screenshots must be done in Power BI Desktop; see README section 'Power BI'.
