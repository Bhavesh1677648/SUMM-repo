#!/usr/bin/env python3
"""MySQL integration tests against a THROWAWAY database (created and dropped by this script).

    export MYSQL_USER=... MYSQL_PASSWORD=... [MYSQL_HOST=127.0.0.1 MYSQL_PORT=3306]
    python testing/test_mysql_integration.py

Never touches retail_customer_intelligence; uses retail_ci_test_<pid>. Exit code 1 on failure.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import traceback
from pathlib import Path

import pandas as pd
import pymysql

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from load_mysql import split_sql  # noqa: E402

RESULTS = ROOT / "testing" / "results"
RESULTS.mkdir(parents=True, exist_ok=True)
HOST, PORT = os.getenv("MYSQL_HOST", "localhost"), int(os.getenv("MYSQL_PORT", "3306"))
USER, PASSWORD = os.getenv("MYSQL_USER"), os.getenv("MYSQL_PASSWORD")
if not USER or PASSWORD is None:
    sys.exit("Set MYSQL_USER and MYSQL_PASSWORD (and MYSQL_HOST if not localhost).")
DB = f"retail_ci_test_{os.getpid()}"
results: list[dict] = []


def connect(db=None):
    return pymysql.connect(host=HOST, port=PORT, user=USER, password=PASSWORD, database=db, charset="utf8mb4", autocommit=True)


def check(test_id, description):
    def deco(fn):
        try:
            detail = fn()
            results.append({"id": test_id, "description": description, "status": "PASS", "detail": detail or ""})
        except AssertionError as exc:
            results.append({"id": test_id, "description": description, "status": "FAIL", "detail": str(exc)})
        except Exception as exc:  # noqa: BLE001
            results.append({"id": test_id, "description": description, "status": "ERROR",
                            "detail": f"{type(exc).__name__}: {exc}\n{traceback.format_exc(limit=2)}"})
        return fn
    return deco


def expect_error(cur, sql, code=None, args=None):
    try:
        cur.execute(sql, args)
    except pymysql.MySQLError as exc:
        if code is not None:
            assert exc.args[0] == code, f"expected MySQL error {code}, got {exc.args}"
        return exc.args
    raise AssertionError(f"statement unexpectedly succeeded: {sql[:80]}")


def run_loader():
    env = dict(os.environ, MYSQL_DATABASE=DB, MYSQL_HOST=HOST, MYSQL_PORT=str(PORT))
    return subprocess.run([sys.executable, str(ROOT / "scripts" / "load_mysql.py")], capture_output=True, text=True, env=env)


customers = pd.read_csv(ROOT / "data" / "cleaned_customer_data.csv")
segments = pd.read_csv(ROOT / "data" / "customer_lfm_segmentation.csv")
registry = pd.read_csv(ROOT / "data" / "kpi_registry.csv")

with connect() as c, c.cursor() as cur:
    cur.execute("SELECT VERSION()")
    VERSION = cur.fetchone()[0]
    cur.execute(f"DROP DATABASE IF EXISTS `{DB}`")


@check("SQL-01", "database_setup.sql runs on an empty database with no errors; tables come out in FK-safe order")
def _():
    sql = (ROOT / "sql" / "database_setup.sql").read_text(encoding="utf-8")
    with connect() as c, c.cursor() as cur:
        cur.execute(f"CREATE DATABASE `{DB}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
        cur.execute(f"USE `{DB}`")
        stmts = [s for s in split_sql(sql) if not s.upper().startswith(("CREATE DATABASE", "USE "))]
        for s in stmts:
            cur.execute(s)
        cur.execute("SHOW TABLES")
        tables = sorted(r[0] for r in cur.fetchall())
    assert tables == ["customer_data", "customer_segments", "kpi_registry"], tables
    # the FK would have made the script fail if customer_segments were created before customer_data
    pos = {t: sql.index(f"CREATE TABLE {t}") for t in tables}
    assert pos["customer_data"] < pos["customer_segments"], "parent must be created before child"
    drops = {t: sql.index(f"DROP TABLE IF EXISTS {t}") for t in tables}
    assert drops["customer_segments"] < drops["customer_data"], "child must be dropped before parent"
    return f"{len(stmts)} statements; create order customer_data -> customer_segments -> kpi_registry; drop order reversed"


@check("SQL-02", "Importing segments BEFORE customers is rejected by the foreign key (proves the required load order)")
def _():
    with connect(DB) as c, c.cursor() as cur:
        row = segments.iloc[0]
        err = expect_error(cur, "INSERT INTO customer_segments VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                           code=1452, args=tuple(int(x) if str(x).lstrip("-").isdigit() else x for x in row.tolist()))
    return f"MySQL error {err[0]}: foreign key constraint fails"


@check("SQL-03", "load_mysql.py loads customer_data first, then customer_segments, then verifies (exit code 0)")
def _():
    p = run_loader()
    assert p.returncode == 0, p.stderr + p.stdout
    assert "LOAD SUCCESS" in p.stdout and p.stdout.count("PASS") == 5 and "FAIL" not in p.stdout, p.stdout
    return "LOAD SUCCESS, 5/5 KPI PASS"


@check("SQL-04", "Row counts: 3,900 customers, 3,900 segments, 5 KPI registry rows; no orphans")
def _():
    with connect(DB) as c, c.cursor() as cur:
        cur.execute("SELECT (SELECT COUNT(*) FROM customer_data),(SELECT COUNT(*) FROM customer_segments),(SELECT COUNT(*) FROM kpi_registry),"
                    "(SELECT COUNT(*) FROM customer_segments s LEFT JOIN customer_data d USING(customer_id) WHERE d.customer_id IS NULL)")
        a, b, k, orphans = cur.fetchone()
    assert (a, b, k, orphans) == (3900, 3900, 5, 0), (a, b, k, orphans)
    assert a == len(customers) and b == len(segments) and k == len(registry)
    return f"{a} / {b} / {k}, orphans={orphans}"


@check("SQL-05", "Primary keys: customer_data(customer_id), customer_segments(customer_id), kpi_registry(kpi_id)")
def _():
    with connect(DB) as c, c.cursor() as cur:
        cur.execute("SELECT table_name, GROUP_CONCAT(column_name ORDER BY ordinal_position) FROM information_schema.key_column_usage "
                    "WHERE table_schema=%s AND constraint_name='PRIMARY' GROUP BY table_name ORDER BY table_name", (DB,))
        pks = dict(cur.fetchall())
    assert pks == {"customer_data": "customer_id", "customer_segments": "customer_id", "kpi_registry": "kpi_id"}, pks
    return str(pks)


@check("SQL-06", "Foreign key: customer_segments.customer_id -> customer_data.customer_id (and delete of a parent with a child is blocked)")
def _():
    with connect(DB) as c, c.cursor() as cur:
        cur.execute("SELECT constraint_name, table_name, column_name, referenced_table_name, referenced_column_name FROM information_schema.key_column_usage "
                    "WHERE table_schema=%s AND referenced_table_name IS NOT NULL", (DB,))
        fks = cur.fetchall()
        assert fks == (("fk_segments_customer", "customer_segments", "customer_id", "customer_data", "customer_id"),), fks
        err = expect_error(cur, "DELETE FROM customer_data WHERE customer_id = 1", code=1451)
    return f"fk_segments_customer OK; parent delete blocked (error {err[0]})"


@check("SQL-07", "Column types: every column of the three tables has the expected MySQL type/precision")
def _():
    expected = {
        "customer_data": {"customer_id": "int", "age": "int", "purchase_amount_usd": "decimal(10,2)", "review_rating": "decimal(3,1)",
                          "previous_purchases": "int", "rating_imputed": "tinyint", "discount_flag": "tinyint", "subscription_flag": "tinyint",
                          "gender": "varchar(20)", "category": "varchar(40)", "age_group": "varchar(10)", "subscription_status": "varchar(10)"},
        "customer_segments": {"customer_id": "int", "purchase_amount_usd": "decimal(10,2)", "L_Score": "tinyint", "F_Score": "tinyint",
                              "M_Score": "tinyint", "LFM_Score": "tinyint", "Customer_Segment": "varchar(40)"},
        "kpi_registry": {"kpi_id": "varchar(10)", "kpi_name": "varchar(100)", "description": "varchar(500)", "calculation_formula": "varchar(500)",
                         "dax_formula": "varchar(500)", "data_source": "varchar(200)", "expected_value": "decimal(12,2)", "unit": "varchar(40)"},
    }
    with connect(DB) as c, c.cursor() as cur:
        cur.execute("SELECT table_name, column_name, column_type, is_nullable FROM information_schema.columns WHERE table_schema=%s", (DB,))
        actual = {(t, col): (typ, nul) for t, col, typ, nul in cur.fetchall()}
    for t, cols in expected.items():
        for col, typ in cols.items():
            got = actual[(t, col)][0]
            assert got == typ, f"{t}.{col}: {got} != {typ}"
    assert not [k for k, v in actual.items() if v[1] == "YES"], "all columns should be NOT NULL"
    cols_csv = {"customer_data": list(customers.columns), "customer_segments": list(segments.columns), "kpi_registry": list(registry.columns)}
    for t, cols in cols_csv.items():
        db_cols = [c for (tt, c) in actual if tt == t]
        assert sorted(db_cols) == sorted(cols), f"{t}: DB columns differ from CSV: {set(db_cols) ^ set(cols)}"
    return f"{len(actual)} columns checked; all NOT NULL; names match CSV headers"


@check("SQL-08", "CHECK constraints enforce valid data (bad subscription_status, rating, age_group, LFM score, KPI ID are rejected)")
def _():
    base = customers.iloc[0].tolist()
    cols = list(customers.columns)
    def row_with(**kw):
        d = dict(zip(cols, base)); d["customer_id"] = 999999; d.update(kw)
        return tuple(int(v) if hasattr(v, "item") and float(v).is_integer() and not isinstance(v, str) else (v.item() if hasattr(v, "item") else v) for v in d.values())
    ph = ",".join(["%s"] * len(cols))
    with connect(DB) as c, c.cursor() as cur:
        for label, kw in [("subscription_status", {"subscription_status": "Maybe"}), ("review_rating", {"review_rating": 9.0}),
                          ("age_group", {"age_group": "Senior"}), ("flag", {"discount_flag": 7})]:
            expect_error(cur, f"INSERT INTO customer_data VALUES ({ph})", code=3819, args=row_with(**kw))
        expect_error(cur, "INSERT INTO kpi_registry VALUES ('KPIX','x','x','x','x','x',1,'x')", code=3819)
        cur.execute("SELECT COUNT(*) FROM customer_data")
        assert cur.fetchone()[0] == 3900
    return "5 invalid rows rejected (error 3819), row count unchanged"


@check("SQL-09", "Re-running the full setup+load on a populated database is idempotent (no manual schema changes needed)")
def _():
    p = run_loader()
    assert p.returncode == 0, p.stderr + p.stdout
    with connect(DB) as c, c.cursor() as cur:
        cur.execute("SELECT (SELECT COUNT(*) FROM customer_data),(SELECT COUNT(*) FROM customer_segments),(SELECT COUNT(*) FROM kpi_registry)")
        assert cur.fetchone() == (3900, 3900, 5)
    return "second run: LOAD SUCCESS, same counts"


@check("SQL-10", "Stale/incompatible old tables are replaced cleanly (old-schema table is dropped and recreated by the loader)")
def _():
    with connect(DB) as c, c.cursor() as cur:
        cur.execute("DROP TABLE customer_segments")
        cur.execute("DROP TABLE kpi_registry")
        cur.execute("DROP TABLE customer_data")
        cur.execute("CREATE TABLE customer_data (customer_id INT PRIMARY KEY, purchase_amount DECIMAL(10,2))")  # old/outdated schema
    p = run_loader()
    assert p.returncode == 0, p.stderr + p.stdout
    with connect(DB) as c, c.cursor() as cur:
        cur.execute("SHOW COLUMNS FROM customer_data")
        names = [r[0] for r in cur.fetchall()]
    assert "purchase_amount_usd" in names and "purchase_amount" not in names, names
    return "old 2-column table replaced by the corrected 24-column schema"


@check("SQL-11", "customer_analysis.sql: all queries execute without error on MySQL and return rows")
def _():
    sql = (ROOT / "sql" / "customer_analysis.sql").read_text(encoding="utf-8")
    stmts = [s for s in split_sql(sql) if not s.upper().startswith("USE ")]
    with connect(DB) as c, c.cursor() as cur:
        counts = []
        for s in stmts:
            cur.execute(s)
            n = len(cur.fetchall())
            if "HAVING COUNT(*) > 1" in s:      # duplicate-customer check: must return ZERO rows
                assert n == 0, f"duplicate customer_id rows found: {n}"
            else:
                assert n > 0, f"query returned no rows: {s[:70]}"
            counts.append(n)
    return f"{len(stmts)} queries ran; row counts {counts}"


@check("SQL-12", "KPI query results: five KPI IDs, live values equal the required baseline, status PASS")
def _():
    sql = (ROOT / "sql" / "customer_analysis.sql").read_text(encoding="utf-8")
    kpi_stmt = next(s for s in split_sql(sql) if "FROM kpi_registry r" in s)
    with connect(DB) as c, c.cursor() as cur:
        cur.execute(kpi_stmt)
        rows = cur.fetchall()
    want = {"KPI-001": 3900, "KPI-002": 233081, "KPI-003": 59.76, "KPI-004": 3.75, "KPI-005": 1053}
    assert [r[0] for r in rows] == list(want), rows
    for r in rows:
        assert float(r[4]) == want[r[0]] and r[6] == "PASS", r
    return "; ".join(f"{r[0]}={float(r[4]):,.2f}" for r in rows)


@check("SQL-13", "Analytical results match pandas (revenue by category, age group, segment) so MySQL and Power BI agree")
def _():
    with connect(DB) as c, c.cursor() as cur:
        cur.execute("SELECT category, SUM(purchase_amount_usd) FROM customer_data GROUP BY category")
        sql_cat = {k: float(v) for k, v in cur.fetchall()}
        cur.execute("SELECT age_group, COUNT(*) FROM customer_data GROUP BY age_group")
        sql_age = dict(cur.fetchall())
        cur.execute("SELECT s.Customer_Segment, COUNT(*), SUM(c.purchase_amount_usd) FROM customer_data c JOIN customer_segments s USING(customer_id) GROUP BY s.Customer_Segment")
        sql_seg = {k: (n, float(v)) for k, n, v in cur.fetchall()}
    assert sql_cat == {k: float(v) for k, v in customers.groupby("category").purchase_amount_usd.sum().items()}
    assert sql_age == customers.groupby("age_group").size().to_dict()
    merged = customers.merge(segments[["customer_id", "Customer_Segment"]], on="customer_id")
    pd_seg = {k: (len(g), float(g.purchase_amount_usd.sum())) for k, g in merged.groupby("Customer_Segment")}
    assert sql_seg == pd_seg, (sql_seg, pd_seg)
    return f"{len(sql_cat)} categories, {len(sql_age)} age groups, {len(sql_seg)} segments identical"


@check("SQL-14", "kpi_registry table content equals data/kpi_registry.csv (dashboard and database use the same KPI IDs)")
def _():
    with connect(DB) as c, c.cursor() as cur:
        cur.execute("SELECT kpi_id,kpi_name,description,calculation_formula,dax_formula,data_source,expected_value,unit FROM kpi_registry ORDER BY kpi_id")
        db = pd.DataFrame(cur.fetchall(), columns=list(registry.columns))
    db["expected_value"] = db["expected_value"].astype(float)
    csv_ = registry.sort_values("kpi_id").reset_index(drop=True).copy()
    csv_["expected_value"] = csv_["expected_value"].astype(float)
    assert db.equals(csv_), "DB registry differs from CSV"
    return "5 rows identical (all 8 columns)"


def main() -> int:
    with connect() as c, c.cursor() as cur:
        cur.execute(f"DROP DATABASE IF EXISTS `{DB}`")
    (RESULTS / "mysql_integration.json").write_text(json.dumps({"mysql_version": VERSION, "results": results}, indent=2), encoding="utf-8")
    print(f"MySQL server version: {VERSION}   (test database {DB}, dropped afterwards)\n")
    for r in results:
        print(f"{r['status']:<5} {r['id']}  {r['description']}")
        if r["status"] != "PASS":
            print("       ->", r["detail"])
    passed = sum(r["status"] == "PASS" for r in results)
    print(f"\n{passed}/{len(results)} MySQL integration checks passed")
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
