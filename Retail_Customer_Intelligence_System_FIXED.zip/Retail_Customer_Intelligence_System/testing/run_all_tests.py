#!/usr/bin/env python3
"""Run every automated check and write testing/test_results.md (+ testing/results/*.json).

    export MYSQL_USER=... MYSQL_PASSWORD=... [MYSQL_HOST=127.0.0.1]   # optional: enables the MySQL tests
    python testing/run_all_tests.py
Power BI Desktop is NOT required; see README for the manual Desktop steps (refresh, screenshots).
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import platform
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "testing" / "results"
RES.mkdir(parents=True, exist_ok=True)
py = sys.executable
steps = []


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def run(label, cmd, env=None):
    p = subprocess.run(cmd, capture_output=True, text=True, cwd=ROOT, env=env or os.environ)
    (RES / f"{label}.log").write_text(p.stdout + p.stderr, encoding="utf-8")
    return p


# 1 CSV validation
p = run("validate_data", [py, "scripts/validate_data.py"])
steps.append(("CSV validation (scripts/validate_data.py)", p.returncode == 0, f"{p.stdout.count('PASS:')} checks passed"))

# 2 notebook start-to-finish (outputs go to a temp file; data CSVs must be reproduced byte-for-byte)
csvs = ["cleaned_customer_data.csv", "customer_lfm_segmentation.csv"]
before = {c: sha(ROOT / "data" / c) for c in csvs}
p = run("notebook", [py, "-m", "jupyter", "nbconvert", "--to", "notebook", "--execute", "--ExecutePreprocessor.timeout=600",
                     "--output", str(RES / "executed_notebook.ipynb"), "python/customer_analysis.ipynb"])
same = all(sha(ROOT / "data" / c) == before[c] for c in csvs)
errs = 0
if p.returncode == 0:
    nb = json.loads((RES / "executed_notebook.ipynb").read_text(encoding="utf-8"))
    errs = sum(1 for c in nb["cells"] if c["cell_type"] == "code" for o in c.get("outputs", []) if o.get("output_type") == "error")
    ncode = sum(1 for c in nb["cells"] if c["cell_type"] == "code")
steps.append(("Notebook executed start to finish (all assertions + KPI-ID checks)", p.returncode == 0 and errs == 0 and same,
              f"{ncode} code cells, {errs} errors, regenerated CSVs identical to committed: {same}" if p.returncode == 0 else p.stderr[-300:]))

# 3 dashboard model
p = run("dashboard_model", [py, "testing/test_dashboard_model.py"])
last = p.stdout.strip().splitlines()[-1] if p.stdout.strip() else p.stderr[-200:]
steps.append(("Power BI project model/visual checks (testing/test_dashboard_model.py)", p.returncode == 0, last))

# 4 MySQL
mysql_ver = "not run"
if os.getenv("MYSQL_USER") and os.getenv("MYSQL_PASSWORD") is not None:
    p = run("mysql_integration", [py, "testing/test_mysql_integration.py"])
    last = p.stdout.strip().splitlines()[-1] if p.stdout.strip() else p.stderr[-300:]
    mysql_ver = p.stdout.splitlines()[0].split("   ")[0] if p.stdout else "?"
    steps.append(("MySQL integration (testing/test_mysql_integration.py)", p.returncode == 0, last))
else:
    steps.append(("MySQL integration", None, "SKIPPED: set MYSQL_USER / MYSQL_PASSWORD"))

import pandas, numpy  # noqa: E402
lines = [f"# Automated test results\n", f"- Run: {dt.datetime.now().strftime('%Y-%m-%d %H:%M')} | Python {platform.python_version()} | pandas {pandas.__version__} | numpy {numpy.__version__} | {mysql_ver}\n",
         "| Step | Result | Detail |", "|---|---|---|"]
for name, ok, detail in steps:
    lines.append(f"| {name} | {'PASS' if ok else ('SKIPPED' if ok is None else 'FAIL')} | {detail} |")
for f, title in (("dashboard_model.json", "Power BI project checks"), ("mysql_integration.json", "MySQL checks")):
    fp = RES / f
    if fp.exists():
        d = json.loads(fp.read_text(encoding="utf-8")); rs = d["results"] if isinstance(d, dict) else d
        lines += ["", f"## {title}", "", "| ID | Result | Check |", "|---|---|---|"] + [f"| {r['id']} | {r['status']} | {r['description']} |" for r in rs]
lines += ["", "## Not covered by automation (requires Power BI Desktop)", "",
          "Opening the PBIP, Refresh, and capturing real screenshots must be done in Power BI Desktop; see README section 'Power BI'."]
(ROOT / "testing" / "test_results.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
print("\n".join(lines[:12]))
sys.exit(0 if all(ok in (True, None) for _, ok, _ in steps) else 1)
