#!/usr/bin/env python3
"""Render a REFERENCE preview of the dashboard from the real visual definitions (positions, titles,
fields) and the model's own DAX. This is NOT a Power BI Desktop screenshot; take those in Desktop.
    python testing/render_reference_dashboard.py
"""
import sys
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pbi_model_sim as sim

PINK, PURPLE, NAVY, TEXT = "#E566B8", "#8B2E9E", "#1A239E", "#252423"
model = sim.load_model(); data = sim.load_data(model); visuals = sim.load_visuals(); full = sim.joined_frame(data)
page_w, page_h = 1500, 940
FMT = {"Total Customers": "{:,.0f}", "Total Revenue": "${:,.0f}", "Average Purchase Value": "${:,.2f}",
       "Average Review Rating": "{:.2f}", "Customers With Subscription": "{:,.0f}"}


def render(selections, out, note):
    df = sim.apply_slicers(full, selections)
    fig = plt.figure(figsize=(15, 9.4), dpi=110); ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, page_w); ax.set_ylim(page_h, 0); ax.axis("off")
    for name, v in visuals.items():
        p = v["position"]; x, y, w, h = p["x"], p["y"], p["width"], p["height"]; vt = v["visual"]["visualType"]
        title = sim.visual_title(v)
        if name == "bg_header":
            ax.add_patch(Rectangle((x, y), w, h, color=PINK)); continue
        if name == "title":
            ax.text(w / 2, y + h / 2, "Customer Behavior Dashboard", ha="center", va="center", fontsize=30, fontweight="bold", color=TEXT); continue
        if name == "bg_filters":
            ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=22", fill=False, ec=PURPLE, lw=1.5)); continue
        if vt == "slicer":
            ref = sim.field_refs(v)[0][2]; ax.text(x, y + 14, title, fontsize=9, fontweight="bold", color=TEXT, va="center")
            for i, member in enumerate(sorted(full[ref].unique())):
                on = (not selections.get(ref)) or member in selections[ref]
                yy = y + 38 + i * 21
                if yy > y + h - 6: break
                ax.add_patch(Rectangle((x + 4, yy - 6), 11, 11, fill=on and bool(selections.get(ref)), fc=PURPLE, ec=PURPLE, lw=1))
                ax.text(x + 22, yy, str(member), fontsize=8, va="center", color=TEXT)
            continue
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=8", fc="white", ec=PURPLE, lw=1.2))
        if vt == "card":
            res = sim.visual_result(v, model, df); k, val = next(iter(res.items()))
            ax.text(x + w / 2, y + 22, title, ha="center", va="center", fontsize=8.5, fontweight="bold", color=TEXT)
            ax.text(x + w / 2, y + h / 2 + 14, FMT[k].format(val), ha="center", va="center", fontsize=26, fontweight="bold", color=PURPLE)
        elif vt == "tableEx":
            ax.text(x + 12, y + 16, title, fontsize=10, fontweight="bold", color=PURPLE, va="center")
            cols = ["kpi_id", "kpi_name", "calculation_formula", "data_source"]; xs = [x + 12, x + 90, x + 330, x + 700]
            ax.add_patch(Rectangle((x + 8, y + 30), w - 16, 16, color=PURPLE))
            for cx, c in zip(xs, cols): ax.text(cx, y + 38, c, fontsize=7.5, color="white", fontweight="bold", va="center")
            for i, r in enumerate(data["kpi_registry"].itertuples()):
                for cx, c in zip(xs, cols): ax.text(cx, y + 56 + i * 15, str(getattr(r, c))[:70], fontsize=7, va="center", color=TEXT)
        else:
            res = sim.visual_result(v, model, df); ax.text(x + 12, y + 18, title, fontsize=9, fontweight="bold", color="#7B1FA2", va="center")
            catc, valc = res.columns[0], res.columns[1]
            if vt == "donutChart":
                ax.set_aspect("auto"); ins = fig.add_axes([(x + w * .22) / page_w, 1 - (y + h - 8) / page_h, w * .56 / page_w, (h - 40) / page_h])
                ins.pie(res[valc], labels=[f"{c} {p:.0f}%" for c, p in zip(res[catc], 100 * res[valc] / res[valc].sum())], wedgeprops=dict(width=.45),
                        colors=["#E566B8" if c == "No" else NAVY for c in res[catc]], textprops=dict(fontsize=8, fontweight="bold"))
            else:
                horizontal = vt == "clusteredBarChart"
                if horizontal and "age_group" != catc: res = res.sort_values(valc)
                ins = fig.add_axes([(x + (w * .30 if horizontal else w * .10)) / page_w, 1 - (y + h - 8) / page_h, (w * (.62 if horizontal else .86)) / page_w, (h - 52) / page_h])
                labels = list(res[catc]); vals = list(res[valc])
                if horizontal:
                    if catc == "age_group": labels, vals = labels[::-1], vals[::-1]
                    ins.barh(labels, vals, color=NAVY)
                    for i, vv in enumerate(vals): ins.text(vv, i, f" {vv:,.0f}", va="center", fontsize=7)
                else:
                    ins.bar(labels, vals, color=NAVY)
                    for i, vv in enumerate(vals): ins.text(i, vv, f"{vv:,.0f}", ha="center", va="bottom", fontsize=7)
                ins.tick_params(labelsize=7.5); [ins.spines[s].set_visible(False) for s in ("top", "right")]
    ax.text(page_w - 8, page_h - 6, note, ha="right", va="bottom", fontsize=8, color="#666", style="italic")
    fig.savefig(out); plt.close(fig); print("wrote", out)


out = Path(__file__).resolve().parents[1] / "screenshots"
note = "REFERENCE RENDER from the dashboard definition + model DAX (not a Power BI Desktop screenshot)"
render({}, out / "dashboard_reference_unfiltered.png", note)
render({"subscription_status": ["Yes"], "age_group": ["25-34", "35-44"]}, out / "dashboard_reference_slicers_applied.png", note + " | slicers: Subscription=Yes, Age Group=25-34, 35-44")
