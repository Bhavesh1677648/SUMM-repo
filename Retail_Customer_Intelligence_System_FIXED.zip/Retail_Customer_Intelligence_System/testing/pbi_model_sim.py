"""Small, dependency-light reader/evaluator for the generated Power BI Project.

Parses the TMDL semantic model and PBIR visuals, loads the CSVs the model points at,
and evaluates the *actual DAX text found in the TMDL* (the five KPI measure patterns)
with relationship-aware filter propagation. This is a verification aid, not a
replacement for Power BI Desktop's engine.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
PB = ROOT / "powerbi"
MODEL = PB / "Retail_Customer_Intelligence.SemanticModel" / "definition"
REPORT = PB / "Retail_Customer_Intelligence.Report" / "definition"
CSV_FOR_TABLE = {"customer_data": "cleaned_customer_data.csv",
                 "customer_segments": "customer_lfm_segmentation.csv",
                 "kpi_registry": "kpi_registry.csv"}


# ----------------------------------------------------------------------------- TMDL
def parse_tmdl_table(path: Path) -> dict:
    lines = path.read_text(encoding="utf-8").splitlines()
    t = {"name": None, "columns": {}, "measures": {}, "partition_m": "", "csv": None}
    cur, mode = None, None
    for i, line in enumerate(lines):
        if line.startswith("table "):
            t["name"] = line.split(None, 1)[1].strip()
        m = re.match(r"^\tcolumn (\S+)$", line)
        if m:
            cur = {"name": m.group(1), "hidden": False}
            t["columns"][cur["name"]] = cur
            mode = "col"
            continue
        m = re.match(r"^\tmeasure '?([^'=]+?)'? = (.*)$", line)
        if m:
            cur = {"name": m.group(1).strip(), "expr": m.group(2).strip(), "format": None}
            t["measures"][cur["name"]] = cur
            mode = "meas"
            continue
        if line.startswith("\tpartition "):
            mode = "part"
            cur = None
            continue
        if mode == "col" and cur is not None:
            m = re.match(r"^\t\t(dataType|sourceColumn|summarizeBy|formatString): (.*)$", line)
            if m:
                cur[m.group(1)] = m.group(2).strip()
            if line.strip() == "isHidden":
                cur["hidden"] = True
        elif mode == "meas" and cur is not None:
            m = re.match(r"^\t\tformatString: (.*)$", line)
            if m:
                cur["format"] = m.group(1).strip()
        elif mode == "part":
            t["partition_m"] += line + "\n"
    m = re.search(r'"\\\\?(\w+\.csv)"', t["partition_m"]) or re.search(r'"\\(\w+\.csv)"', t["partition_m"])
    t["csv"] = m.group(1) if m else None
    # M column/type pairs from Table.TransformColumnTypes
    t["m_types"] = re.findall(r'\{"(\w+)", ([A-Za-z0-9_. ]+?)\}', t["partition_m"])
    return t


def load_model() -> dict:
    tables = {}
    for p in sorted((MODEL / "tables").glob("*.tmdl")):
        t = parse_tmdl_table(p)
        tables[t["name"]] = t
    rel_text = (MODEL / "relationships.tmdl").read_text(encoding="utf-8")
    rel = {k: v.strip() for k, v in re.findall(r"^\t(\w+): (.*)$", rel_text, re.M)}
    return {"tables": tables, "relationship": rel, "relationship_text": rel_text,
            "model_text": (MODEL / "model.tmdl").read_text(encoding="utf-8"),
            "expressions_text": (MODEL / "expressions.tmdl").read_text(encoding="utf-8")}


def load_data(model: dict) -> dict[str, pd.DataFrame]:
    return {n: pd.read_csv(ROOT / "data" / (t["csv"] or CSV_FOR_TABLE[n])) for n, t in model["tables"].items()}


# ----------------------------------------------------------------------------- PBIR
def load_visuals() -> dict[str, dict]:
    out = {}
    for p in sorted((REPORT / "pages").glob("*/visuals/*/visual.json")):
        out[p.parent.name] = json.loads(p.read_text(encoding="utf-8"))
    return out


def field_refs(visual: dict) -> list[tuple[str, str, str]]:
    """(kind, entity, property) for every field a visual queries."""
    refs = []
    def walk(o):
        if isinstance(o, dict):
            for kind in ("Column", "Measure"):
                if kind in o and isinstance(o[kind], dict) and "Expression" in o[kind] and "Property" in o[kind]:
                    ent = o[kind]["Expression"].get("SourceRef", {}).get("Entity")
                    refs.append((kind, ent, o[kind]["Property"]))
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
    walk(visual.get("visual", {}).get("query", {}))
    return refs


def visual_title(visual: dict) -> str | None:
    try:
        v = visual["visual"]["visualContainerObjects"]["title"][0]["properties"]["text"]["expr"]["Literal"]["Value"]
        return v.strip("'")
    except (KeyError, IndexError):
        return None


# ----------------------------------------------------------------------------- DAX subset
def eval_measure(expr: str, df: pd.DataFrame):
    """Evaluate the DAX forms used by the KPI measures on an already-filtered frame."""
    e = expr.strip()
    m = re.fullmatch(r"DISTINCTCOUNT\((\w+)\[(\w+)\]\)", e)
    if m:
        return df[m.group(2)].nunique()
    m = re.fullmatch(r"SUM\((\w+)\[(\w+)\]\)", e)
    if m:
        return df[m.group(2)].sum()
    m = re.fullmatch(r"AVERAGE\((\w+)\[(\w+)\]\)", e)
    if m:
        return df[m.group(2)].mean()
    m = re.fullmatch(r'CALCULATE\(DISTINCTCOUNT\((\w+)\[(\w+)\]\),\s*(\w+)\[(\w+)\]\s*=\s*"([^"]*)"\)', e)
    if m:
        return df.loc[df[m.group(4)] == m.group(5), m.group(2)].nunique()
    raise ValueError(f"Unsupported DAX in simulator: {expr}")


def joined_frame(data: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """customer_data joined 1:1 to customer_segments; segment columns get a table prefix key."""
    seg = data["customer_segments"][["customer_id", "L_Score", "F_Score", "M_Score", "LFM_Score", "Customer_Segment"]]
    return data["customer_data"].merge(seg, on="customer_id", how="left", validate="one_to_one")


def apply_slicers(df: pd.DataFrame, selections: dict[str, list] | None) -> pd.DataFrame:
    for column, values in (selections or {}).items():
        df = df[df[column].isin(values)]
    return df


def visual_result(visual: dict, model: dict, df: pd.DataFrame) -> pd.DataFrame | dict:
    """Compute the data a visual would plot given a filtered, joined frame."""
    q = visual["visual"].get("query", {}).get("queryState", {})
    measures = {n: m["expr"] for t in model["tables"].values() for n, m in t["measures"].items()}
    vt = visual["visual"]["visualType"]
    if vt == "card":
        prop = q["Values"]["projections"][0]["field"]["Measure"]["Property"]
        return {prop: eval_measure(measures[prop], df)}
    cats = [p["field"]["Column"]["Property"] for r, d in q.items() if r == "Category" for p in d["projections"]]
    ys = [p["field"]["Measure"]["Property"] for r, d in q.items() if r == "Y" for p in d["projections"]]
    if cats and ys:
        rows = []
        for key, g in df.groupby(cats[0], observed=True):
            rows.append({cats[0]: key, ys[0]: eval_measure(measures[ys[0]], g)})
        return pd.DataFrame(rows)
    return {}
