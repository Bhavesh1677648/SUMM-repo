#!/usr/bin/env python3
"""Verification of the Power BI Project: model, column references, KPI IDs/values,
filters, chart bindings and slicer behaviour. Exit code 1 on any failure.

    python testing/test_dashboard_model.py            # prints results, writes testing/results/dashboard_model.json
"""
from __future__ import annotations

import json
import re
import sys
import traceback
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pbi_model_sim as sim  # noqa: E402

ROOT = sim.ROOT
RESULTS = ROOT / "testing" / "results"
RESULTS.mkdir(parents=True, exist_ok=True)

# Independent baseline supplied by the project owner (NOT read from the registry).
BASELINE = {"KPI-001": 3900, "KPI-002": 233081, "KPI-003": 59.76, "KPI-004": 3.75, "KPI-005": 1053}
AGE_GROUPS = ["18-24", "25-34", "35-44", "45-54", "55-64", "65+"]
SEGMENT_EXPECTED = {  # customers, revenue (from the verified notebook/README output)
    "Potential Loyalists": (1734, 103287), "Loyal": (795, 58890), "Needs Attention": (795, 37395),
    "Low Engagement": (302, 10293), "Champions": (274, 23216)}

results: list[dict] = []


def check(test_id: str, description: str):
    def deco(fn):
        try:
            detail = fn()
            results.append({"id": test_id, "description": description, "status": "PASS", "detail": detail or ""})
        except AssertionError as exc:
            results.append({"id": test_id, "description": description, "status": "FAIL", "detail": str(exc)})
        except Exception as exc:  # noqa: BLE001
            results.append({"id": test_id, "description": description, "status": "ERROR",
                            "detail": f"{type(exc).__name__}: {exc}\n{traceback.format_exc(limit=2)}"})
        return fn
    return deco


model = sim.load_model()
data = sim.load_data(model)
visuals = sim.load_visuals()
registry = pd.read_csv(ROOT / "data" / "kpi_registry.csv")
full = sim.joined_frame(data)
measures = {n: m for t in model["tables"].values() for n, m in t["measures"].items()}
report_text = "\n".join(p.read_text(encoding="utf-8") for p in sim.REPORT.rglob("*.json"))
model_text = "\n".join(p.read_text(encoding="utf-8") for p in sim.MODEL.rglob("*.tmdl"))
cards = {n: v for n, v in visuals.items() if v["visual"]["visualType"] == "card"}
slicers = {n: v for n, v in visuals.items() if v["visual"]["visualType"] == "slicer"}
charts = {n: v for n, v in visuals.items() if v["visual"]["visualType"] in
          ("clusteredColumnChart", "clusteredBarChart", "donutChart")}


@check("PBI-01", "PBIR/TMDL JSON validates against Microsoft's published schemas")
def _():
    sys.path.insert(0, str(ROOT / "testing"))
    import validate_pbir_schema as v
    ok, msg = v.run()
    assert ok, msg
    return msg


@check("PBI-02", "Model has exactly customer_data, customer_segments, kpi_registry (no PostgreSQL 'public customer')")
def _():
    assert set(model["tables"]) == {"customer_data", "customer_segments", "kpi_registry"}, set(model["tables"])
    assert "PostgreSQL" not in model_text and "public customer" not in model_text
    return "tables: " + ", ".join(sorted(model["tables"]))


@check("PBI-03", "Every TMDL column name/sourceColumn equals the CSV header, in order (column references up to date)")
def _():
    for name, t in model["tables"].items():
        csv_cols = list(data[name].columns)
        assert list(t["columns"]) == csv_cols, f"{name}: model {list(t['columns'])} != csv {csv_cols}"
        assert [c for c, _ in t["m_types"]] == csv_cols, f"{name}: M type list does not match CSV header"
        for c, col in t["columns"].items():
            assert col["sourceColumn"] == c, f"{name}.{c} sourceColumn={col['sourceColumn']}"
    return "; ".join(f"{n}: {len(t['columns'])} cols" for n, t in model["tables"].items())


@check("PBI-04", "Column data types are compatible with the CSV values (no nulls, ints are ints, numbers are numeric)")
def _():
    bad = []
    for name, t in model["tables"].items():
        df = data[name]
        for c, col in t["columns"].items():
            s, dt = df[c], col["dataType"]
            if s.isna().any():
                bad.append(f"{name}.{c} has nulls")
            if dt == "int64" and not pd.api.types.is_integer_dtype(s):
                bad.append(f"{name}.{c} not integer")
            if dt in ("double", "decimal") and not pd.api.types.is_numeric_dtype(s):
                bad.append(f"{name}.{c} not numeric")
            if dt == "string" and pd.api.types.is_numeric_dtype(s):
                bad.append(f"{name}.{c} numeric data typed as string")
    assert not bad, bad
    return "all columns typed consistently"


@check("PBI-05", "customer_segments->customer_data is one-to-one on customer_id, keys unique, same ID sets, registry not related")
def _():
    r = model["relationship"]
    assert r["fromColumn"] == "customer_segments.customer_id" and r["toColumn"] == "customer_data.customer_id", r
    assert r["fromCardinality"] == "one" and r["toCardinality"] == "one", r
    assert r["crossFilteringBehavior"] == "bothDirections", r
    assert data["customer_data"].customer_id.is_unique and data["customer_segments"].customer_id.is_unique
    assert set(data["customer_data"].customer_id) == set(data["customer_segments"].customer_id)
    assert model["relationship_text"].count("relationship ") == 1 and "kpi_registry" not in "".join(
        l for l in model["relationship_text"].splitlines() if not l.startswith("///"))
    return "1 relationship, 3,900 keys matched"


@check("PBI-06", "Every field used by every visual resolves to an existing model column or measure")
def _():
    n = 0
    for vname, v in visuals.items():
        for kind, ent, prop in sim.field_refs(v):
            t = model["tables"].get(ent)
            assert t is not None, f"{vname}: unknown table {ent}"
            pool = t["columns"] if kind == "Column" else t["measures"]
            assert prop in pool, f"{vname}: {ent}[{prop}] ({kind}) not found in model"
            n += 1
    return f"{n} field references in {len(visuals)} visuals resolved"


@check("PBI-07", "Revenue uses customer_data[purchase_amount_usd]; no visual binds the duplicate hidden segment columns")
def _():
    assert measures["Total Revenue"]["expr"] == "SUM(customer_data[purchase_amount_usd])"
    assert measures["Average Purchase Value"]["expr"] == "AVERAGE(customer_data[purchase_amount_usd])"
    for c in ("previous_purchases", "purchase_amount_usd", "frequency_of_purchases"):
        assert model["tables"]["customer_segments"]["columns"][c]["hidden"], f"customer_segments.{c} should be hidden"
    for vname, v in visuals.items():
        for kind, ent, prop in sim.field_refs(v):
            assert not (ent == "customer_segments" and prop in ("previous_purchases", "purchase_amount_usd", "frequency_of_purchases")), vname
    return "revenue measures reference purchase_amount_usd only"


@check("PBI-08", "No outdated names remain (public customer, purchase_amount without _usd, old age labels, Number of Customers, 'Sales by')")
def _():
    both = report_text + model_text
    for pat, label in [(r"public customer", "public customer"), (r"purchase_amount(?!_usd)", "purchase_amount"),
                       (r"Young Adult|Middle-aged|\bSenior\b", "old age labels"), (r"Number of Customers", "Number of Customers"),
                       (r"Sales by", "'Sales by' title"), (r"Sum\(.*customer_id", "Sum(customer_id)")]:
        assert not re.search(pat, both), f"stale reference found: {label}"
    return "none found"


@check("PBI-09", "No hard-coded/saved filters anywhere (no Accessories, filterConfig, Where clauses, saved slicer selections)")
def _():
    assert "Accessories" not in report_text and "Accessories" not in model_text
    assert "filterConfig" not in report_text, "filterConfig present"
    assert '"Where"' not in report_text and '"filter"' not in report_text, "saved filter expression present"
    for vname, v in slicers.items():
        assert "general" not in v["visual"].get("objects", {}), f"{vname} has a saved general.filter"
    page = json.loads(next((sim.REPORT / "pages").glob("*/page.json")).read_text(encoding="utf-8"))
    assert "visualInteractions" not in page, "page overrides slicer interactions"
    return "0 filters; 0 interaction overrides"


@check("PBI-10", "Five KPI cards, one per ID, titles read 'KPI-00X | Name' exactly as in kpi_registry")
def _():
    assert len(cards) == 5, f"expected 5 cards, found {len(cards)}"
    seen = {}
    for vname, v in cards.items():
        title = sim.visual_title(v)
        m = re.fullmatch(r"(KPI-\d{3}) \| (.+)", title or "")
        assert m, f"{vname}: title {title!r} lacks 'KPI-xxx | name'"
        seen[m.group(1)] = (m.group(2), v["visual"]["query"]["queryState"]["Values"]["projections"][0]["field"]["Measure"]["Property"])
    assert sorted(seen) == [f"KPI-00{i}" for i in range(1, 6)], sorted(seen)
    for row in registry.itertuples():
        name, measure = seen[row.kpi_id]
        assert name == row.kpi_name == measure, f"{row.kpi_id}: title={name!r} measure={measure!r} registry={row.kpi_name!r}"
    return ", ".join(f"{k}={v[0]}" for k, v in sorted(seen.items()))


@check("PBI-11", "Measure DAX in the model equals kpi_registry.dax_formula for all five KPIs")
def _():
    for row in registry.itertuples():
        assert measures[row.kpi_name]["expr"] == row.dax_formula, f"{row.kpi_id}: {measures[row.kpi_name]['expr']} != {row.dax_formula}"
    return "5/5 identical"


@check("PBI-12", "Unfiltered KPI cards evaluate to the required baseline values (evaluating the DAX text from the model)")
def _():
    lines = []
    for row in registry.itertuples():
        val = sim.eval_measure(measures[row.kpi_name]["expr"], full)
        want = BASELINE[row.kpi_id]
        assert round(float(val), 2) == round(float(want), 2), f"{row.kpi_id} {row.kpi_name}: got {val}, expected {want}"
        assert round(float(row.expected_value), 2) == round(float(want), 2), f"registry expected_value drifted for {row.kpi_id}"
        lines.append(f"{row.kpi_id}={val:,.2f}")
    return "; ".join(lines)


@check("PBI-13", "Measure number formats display the expected text (3,900 / $233,081 / $59.76 / 3.75 / 1,053)")
def _():
    fmt = {"Total Customers": ("#,0", lambda v: f"{v:,.0f}"), "Total Revenue": ("\\$#,0", lambda v: f"${v:,.0f}"),
           "Average Purchase Value": ("\\$#,0.00", lambda v: f"${v:,.2f}"), "Average Review Rating": ("0.00", lambda v: f"{v:.2f}"),
           "Customers With Subscription": ("#,0", lambda v: f"{v:,.0f}")}
    shown = {}
    for name, (f, render) in fmt.items():
        assert measures[name]["format"] == f, f"{name} formatString {measures[name]['format']!r} != {f!r}"
        shown[name] = render(float(sim.eval_measure(measures[name]["expr"], full)))
    assert list(shown.values()) == ["3,900", "$233,081", "$59.76", "3.75", "1,053"], shown
    for v in cards.values():
        lb = v["visual"]["objects"]["labels"][0]["properties"]["labelDisplayUnits"]["expr"]["Literal"]["Value"]
        assert lb == "0D", "card display units must be 'None' so 3,900 is not shown as 3.9K"
    return ", ".join(shown.values())


@check("PBI-14", "Average Purchase Value: per-record equals per-customer (one row per customer), so the definition is unambiguous")
def _():
    per_record = full.purchase_amount_usd.mean()
    per_customer = full.groupby("customer_id").purchase_amount_usd.sum().mean()
    assert full.customer_id.is_unique and abs(per_record - per_customer) < 1e-9
    return f"${per_record:.4f} both ways"


@check("PBI-15", "KPI registry table visual shows ID, name, formula, data source, description from kpi_registry")
def _():
    v = visuals["table_kpi_registry"]
    props = [p for k, e, p in sim.field_refs(v) if e == "kpi_registry"]
    for need in ("kpi_id", "kpi_name", "calculation_formula", "data_source", "description"):
        assert need in props, f"{need} missing from registry table"
    assert len(data["kpi_registry"]) == 5
    return f"columns shown: {', '.join(dict.fromkeys(props))}"


@check("PBI-16", "Age-group charts use age_group with exactly the six correct bands (no old four labels)")
def _():
    found = 0
    for vname, v in charts.items():
        refs = sim.field_refs(v)
        if any(p == "age_group" for _, _, p in refs):
            res = sim.visual_result(v, model, full)
            assert list(res["age_group"]) == AGE_GROUPS, f"{vname}: {list(res['age_group'])}"
            found += 1
    assert found == 2, f"expected 2 age-group charts, found {found}"
    return "2 charts x 6 bands: " + ", ".join(AGE_GROUPS)


@check("PBI-17", "LFM segmentation visuals exist and reproduce the verified segment counts and revenue")
def _():
    seg_charts = {n: v for n, v in charts.items() if any(p == "Customer_Segment" for _, _, p in sim.field_refs(v))}
    assert len(seg_charts) == 2, list(seg_charts)
    for vname, v in seg_charts.items():
        res = sim.visual_result(v, model, full).set_index("Customer_Segment")
        assert set(res.index) == set(SEGMENT_EXPECTED), set(res.index)
        measure = [c for c in res.columns][0]
        for seg, (cust, rev) in SEGMENT_EXPECTED.items():
            want = cust if measure == "Total Customers" else rev
            assert float(res.loc[seg, measure]) == want, f"{vname} {seg}: {res.loc[seg, measure]} != {want}"
    return "segments: " + ", ".join(f"{k} {v[0]}/${v[1]:,}" for k, v in SEGMENT_EXPECTED.items())


@check("PBI-18", "Chart titles match their aggregation (Revenue->Total Revenue, Customers->Total Customers); no 'Sales by'")
def _():
    for vname, v in charts.items():
        title = sim.visual_title(v)
        meas = list(dict.fromkeys(p for k, e, p in sim.field_refs(v) if k == "Measure"))  # de-dupe (sort field repeats the measure)
        assert title and meas, vname
        if title.startswith("Revenue"):
            assert meas == ["Total Revenue"], f"{vname}: {title} uses {meas}"
        elif "Customers" in title:
            assert meas == ["Total Customers"], f"{vname}: {title} uses {meas}"
        else:
            raise AssertionError(f"{vname}: unrecognised title {title}")
        assert "Sales" not in title
    return "; ".join(sorted(sim.visual_title(v) for v in charts.values()))


@check("PBI-19", "Every chart reconciles to its KPI total (catches wrong aggregation such as Sum(customer_id))")
def _():
    for vname, v in charts.items():
        res = sim.visual_result(v, model, full)
        meas = [c for c in res.columns][1]
        total = res[meas].sum()
        want = 3900 if meas == "Total Customers" else 233081
        assert round(float(total), 2) == want, f"{vname}: sums to {total}, expected {want}"
    return f"{len(charts)} charts reconcile to 3,900 customers / $233,081"


@check("PBI-20", "Slicers: for every slicer member, KPI cards equal an independent pandas calculation; members partition the total")
def _():
    n_checks = 0
    for vname, v in slicers.items():
        _, ent, prop = sim.field_refs(v)[0]
        assert ent in ("customer_data", "customer_segments") and prop in full.columns, vname
        parts = {k: 0 for k in ("Total Customers", "Total Revenue")}
        for member in sorted(full[prop].unique()):
            sel = sim.apply_slicers(full, {prop: [member]})
            sub = full[full[prop] == member]  # independent computation
            exp = {"Total Customers": sub.customer_id.nunique(), "Total Revenue": sub.purchase_amount_usd.sum(),
                   "Average Purchase Value": sub.purchase_amount_usd.mean(), "Average Review Rating": sub.review_rating.mean(),
                   "Customers With Subscription": (sub.subscription_status == "Yes").sum()}
            for name, want in exp.items():
                got = sim.eval_measure(measures[name]["expr"], sel)
                assert abs(float(got) - float(want)) < 1e-9, f"{vname}={member}: {name} {got} != {want}"
                n_checks += 1
            parts["Total Customers"] += exp["Total Customers"]
            parts["Total Revenue"] += exp["Total Revenue"]
        assert parts["Total Customers"] == 3900 and parts["Total Revenue"] == 233081, f"{vname} members do not partition the data: {parts}"
    return f"{len(slicers)} slicers, {n_checks} member/KPI checks"


@check("PBI-21", "Slicer behaviour on charts: filtering one category/segment/age group only changes the matching bars")
def _():
    sel = sim.apply_slicers(full, {"category": ["Accessories"]})
    cat_chart = sim.visual_result(visuals["col_customers_category"], model, sel)
    assert list(cat_chart["category"]) == ["Accessories"] and cat_chart["Total Customers"].iloc[0] == 1240
    seg_sel = sim.apply_slicers(full, {"Customer_Segment": ["Champions"]})
    r = sim.visual_result(visuals["bar_revenue_segment"], model, seg_sel)
    assert list(r["Customer_Segment"]) == ["Champions"] and r["Total Revenue"].iloc[0] == 23216
    age_sel = sim.apply_slicers(full, {"age_group": ["65+"]})
    r = sim.visual_result(visuals["bar_customers_age"], model, age_sel)
    assert list(r["age_group"]) == ["65+"] and r["Total Customers"].iloc[0] == 427
    combo = sim.apply_slicers(full, {"subscription_status": ["Yes"], "gender": ["Female"]})
    assert sim.eval_measure(measures["Total Customers"]["expr"], combo) == full[(full.subscription_status == "Yes") & (full.gender == "Female")].customer_id.nunique()
    return "Accessories=1,240 | Champions=$23,216 | 65+=427 | Yes&Female combo OK"


@check("PBI-22", "KPI Registry table is unaffected by slicers (no relationship) while KPI cards respond to them")
def _():
    assert "kpi_registry" not in model["relationship_text"].replace("/// kpi_registry is metadata and is deliberately NOT related to customer data.", "")
    sel = sim.apply_slicers(full, {"category": ["Footwear"]})
    assert sim.eval_measure(measures["Total Customers"]["expr"], sel) == 599
    return "registry independent; Footwear slicer -> KPI-001 = 599"


@check("PBI-23", "Layout: every visual lies inside the 1500x940 page and data visuals do not overlap")
def _():
    page = json.loads(next((sim.REPORT / "pages").glob("*/page.json")).read_text(encoding="utf-8"))
    W, H = page["width"], page["height"]
    data_visuals = {n: v for n, v in visuals.items() if v["visual"]["visualType"] not in ("shape", "textbox")}
    for n, v in visuals.items():
        p = v["position"]
        assert p["x"] >= 0 and p["y"] >= 0 and p["x"] + p["width"] <= W + 0.5 and p["y"] + p["height"] <= H + 0.5, f"{n} out of bounds: {p}"
    names = list(data_visuals)
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            pa, pb = data_visuals[a]["position"], data_visuals[b]["position"]
            overlap = pa["x"] < pb["x"] + pb["width"] and pb["x"] < pa["x"] + pa["width"] and pa["y"] < pb["y"] + pb["height"] and pb["y"] < pa["y"] + pa["height"]
            assert not overlap, f"{a} overlaps {b}"
    return f"{len(visuals)} visuals in bounds; {len(names)} data visuals non-overlapping"


@check("PBI-24", "DataFolder parameter exists and every table's CSV file is present in data/")
def _():
    assert "expression DataFolder" in model["expressions_text"] and "IsParameterQuery = true" in model["expressions_text"]
    for n, t in model["tables"].items():
        assert "DataFolder" in t["partition_m"], f"{n} does not use DataFolder"
        assert (ROOT / "data" / t["csv"]).exists(), f"{t['csv']} missing"
    return "3 tables -> " + ", ".join(t["csv"] for t in model["tables"].values())


def main() -> int:
    out = RESULTS / "dashboard_model.json"
    out.write_text(json.dumps(results, indent=2), encoding="utf-8")
    width = max(len(r["id"]) for r in results)
    for r in results:
        print(f"{r['status']:<5} {r['id']:<{width}}  {r['description']}")
        if r["status"] != "PASS":
            print("       ->", r["detail"])
    passed = sum(r["status"] == "PASS" for r in results)
    print(f"\n{passed}/{len(results)} dashboard-model checks passed")
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
