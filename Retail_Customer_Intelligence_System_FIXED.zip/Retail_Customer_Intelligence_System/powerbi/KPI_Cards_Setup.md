# Power BI: KPI cards, KPI IDs and setup

## Open and refresh (about 2 minutes)
1. `python scripts/set_powerbi_data_path.py` (once; writes the absolute `data/` path into the `DataFolder` parameter).
2. Open `powerbi/Retail_Customer_Intelligence.pbip` in Power BI Desktop (a current build with PBIR/TMDL support; if prompted, enable the Power BI Project preview/feature).
3. **Home > Refresh.** Expected: three tables load (`customer_data` 3,900 rows, `customer_segments` 3,900, `kpi_registry` 5) with no errors.
4. Optional: **File > Save as** `.pbix`.

## KPI cards (every card shows its ID in its title)
| KPI ID | Card title | Measure | Value, no slicer selected |
|---|---|---|---:|
| KPI-001 | KPI-001 \| Total Customers | `Total Customers` | 3,900 |
| KPI-002 | KPI-002 \| Total Revenue | `Total Revenue` | $233,081 |
| KPI-003 | KPI-003 \| Average Purchase Value | `Average Purchase Value` | $59.76 |
| KPI-004 | KPI-004 \| Average Review Rating | `Average Review Rating` | 3.75 |
| KPI-005 | KPI-005 \| Customers With Subscription | `Customers With Subscription` | 1,053 |

The card titles, measure names, DAX and registry rows all come from `data/kpi_registry.csv` (= MySQL `kpi_registry`). Card values shown as 3,900 / $233,081 (display units set to None, not 3.9K). To change a KPI, edit `sql/database_setup.sql`, re-export the CSV, run `python scripts/build_powerbi_project.py` and `python testing/run_all_tests.py`.

## Filters
No visual, page or report carries a saved filter. KPI cards cover the full dataset until a slicer is used. Slicers (Subscription Status, Gender, Category, Age Group, LFM Customer Segment, Shipping Type) filter the cards and every chart; the KPI registry table is metadata and is intentionally unaffected.

## Use MySQL instead of CSV (optional, not exercised by the automated tests)
Install the MySQL connector for Power BI, then in **Transform data** replace the three table sources, e.g.:
```m
let
    Source = MySQL.Database("localhost:3306", "retail_customer_intelligence"),
    customer_data = Source{[Schema = "retail_customer_intelligence", Item = "customer_data"]}[Data]
in
    customer_data
```
Repeat for `customer_segments` and `kpi_registry`. Column names are identical to the CSV headers, so no visual or measure changes are needed.

## Troubleshooting
- *"Could not find file ..."*: `DataFolder` is wrong; re-run `scripts/set_powerbi_data_path.py` or edit it in **Transform data > Manage Parameters**.
- *Project will not open*: update Power BI Desktop; if a TMDL/PBIR error names a file, send the message so the generator can be adjusted.
- *Numbers differ from the table above*: check for a slicer selection (cards respect slicers by design).
