# Retail Customer Intelligence System

A reproducible BCA data analytics project exploring a retail customer sample with Python, pandas, MySQL, SQL and Power BI.

## Scope and data grain
The supplied source contains **3,900 rows and 18 columns**, with one row per customer ID. It is not transaction-level history: do not interpret row counts as orders, and do not calculate true transaction frequency from customer row counts. There is no purchase date, so true RFM recency cannot be calculated. The corrected notebook uses **LFM (Loyalty–Frequency–Monetary)**: `previous_purchases` is a loyalty proxy, `frequency_of_purchases` is mapped to a frequency score (`Weekly = 5`, `Fortnightly = 4`, `Bi-Weekly = 4`, `Monthly = 3`, `Quarterly = 2`, `Every 3 Months = 2`, `Annually = 1`), and `purchase_amount_usd` is monetary value. `"Bi-Weekly"` is interpreted as every two weeks (equivalent to `"Fortnightly"`, scored 4); see the limitation note below regarding its linguistic ambiguity.

## Data Source
- **Dataset:** Customer Shopping Trends Dataset (`customer_shopping_data.csv`, 3,900 records, 18 columns; the supplied copy includes 37 missing `Review Rating` values for data-cleaning practice)
- **Author:** Sourav Banerjee (`iamsouravbanerjee`)
- **Original download URL:** https://www.kaggle.com/datasets/iamsouravbanerjee/customer-shopping-trends-dataset
- **Licence:** Other (specified in description) — synthetic dataset created for educational data analysis and machine learning practice (if your copy was obtained from an institutional mirror, retain that page's attribution alongside this source).

## Project structure
```text
Retail_Customer_Intelligence_System/
├── data/
│   ├── customer_shopping_data.csv       # original source
│   ├── cleaned_customer_data.csv        # cleaned + engineered features
│   ├── customer_lfm_segmentation.csv    # LFM output (1:1 with customers)
│   └── kpi_registry.csv                 # KPI-001..KPI-005 (same rows as the MySQL kpi_registry table)
├── python/customer_analysis.ipynb       # end-to-end analysis, charts, exports, tests, KPI-ID checks
├── sql/
│   ├── database_setup.sql               # MySQL 8 schema + kpi_registry seed (drops/recreates project tables)
│   └── customer_analysis.sql            # 13 business/verification queries
├── scripts/
│   ├── load_mysql.py                    # schema + FK-ordered load + verification
│   ├── validate_data.py                 # 15 CSV checks, no database needed
│   ├── build_powerbi_project.py         # regenerates the Power BI project from kpi_registry.csv
│   └── set_powerbi_data_path.py         # one-time: point Power BI at this data/ folder
├── powerbi/
│   ├── Retail_Customer_Intelligence.pbip            # OPEN THIS in Power BI Desktop
│   ├── Retail_Customer_Intelligence.SemanticModel/  # TMDL model: 3 tables, 1 relationship, 5 KPI measures
│   ├── Retail_Customer_Intelligence.Report/         # PBIR report: 22 visuals, no filters
│   ├── KPI_Cards_Setup.md, KPI_Measures.dax
│   └── legacy/                                      # old stale .pbix (PostgreSQL source) kept for reference only
├── testing/                              # run_all_tests.py, test_results.md, Test_Cases.docx
├── screenshots/                          # incl. dashboard_reference_*.png (reference renders)
├── diagram/  documentation/user_manual.docx  requirements.txt
```

## Setup
1. Install Python 3.10+ (tested on Python 3.13 with `pandas 3.0.2` / `3.0.3`; `requirements.txt` specifies `pandas>=2.0`) and MySQL 8+ if database integration is required.
2. Create a virtual environment: `python -m venv .venv` and activate it.
3. Install dependencies: `pip install -r requirements.txt`.
4. Open `python/customer_analysis.ipynb` in Jupyter from the project root. Run cells from top to bottom. The notebook reads `data/customer_shopping_data.csv`, validates data, creates charts, writes `data/cleaned_customer_data.csv` and `data/customer_lfm_segmentation.csv`, and runs assertions.
5. Validate the supplied CSVs without MySQL: `python scripts/validate_data.py`.
6. MySQL (8.0+): set `MYSQL_USER` and `MYSQL_PASSWORD` (optionally `MYSQL_HOST`, `MYSQL_PORT`, `MYSQL_DATABASE`) and run `python scripts/load_mysql.py`. It runs `sql/database_setup.sql` (the single source of truth for the schema), then loads `customer_data` **before** `customer_segments` (foreign key), and verifies row counts, the five KPIs and the registry. **The setup script drops and recreates the three project tables** (`customer_segments`, `customer_data`, `kpi_registry`) in the target database on every run; other tables/databases are untouched. No manual schema changes are needed. Manual alternative: `mysql -u USER -p < sql/database_setup.sql`, then import the two CSVs in the same order.
   **Ready-made database:** `sql/retail_customer_intelligence_full_dump.sql` is a full MySQL 8 dump (schema, constraints, all data, KPI registry). Import it with `mysql -u USER -p < sql/retail_customer_intelligence_full_dump.sql` instead of running the loader (it recreates the `retail_customer_intelligence` database).
7. Run `sql/customer_analysis.sql` (query 11 recomputes KPI-001..KPI-005 from the tables and compares them with `kpi_registry`).
8. Power BI: see the next section.
9. Run everything: `python testing/run_all_tests.py` (results in `testing/test_results.md`).

## KPI IDs and registry
| KPI ID | KPI | Value (full dataset) | Formula (SQL) | Data source |
|---|---|---:|---|---|
| KPI-001 | Total Customers | 3,900 | `COUNT(DISTINCT customer_id)` | `customer_data.customer_id` |
| KPI-002 | Total Revenue | $233,081 | `SUM(purchase_amount_usd)` | `customer_data.purchase_amount_usd` |
| KPI-003 | Average Purchase Value | $59.76 | `AVG(purchase_amount_usd)` | `customer_data.purchase_amount_usd` |
| KPI-004 | Average Review Rating | 3.75 | `AVG(review_rating)` | `customer_data.review_rating` |
| KPI-005 | Customers With Subscription | 1,053 | `COUNT(DISTINCT customer_id) WHERE subscription_status='Yes'` | `customer_data.customer_id`, `.subscription_status` |

The registry (`kpi_id, kpi_name, description, calculation_formula, dax_formula, data_source, expected_value, unit`) lives in the MySQL table `kpi_registry`, in `data/kpi_registry.csv`, and in the Power BI model. The dashboard shows each ID in its KPI card title (`KPI-001 | Total Customers`) and lists the whole registry in a table at the bottom. **Average Purchase Value:** the data has one row per customer, so "average transaction value" and "average customer spend" are the same number ($59.76); this is verified in the notebook, SQL query 12 and the tests. If transaction-level data is ever added, redefine KPI-003 explicitly.

## Power BI
The dashboard is delivered as a **Power BI Project** (`powerbi/Retail_Customer_Intelligence.pbip`), a text-based, schema-validated format that Power BI Desktop (current builds, which support PBIR/TMDL) opens directly:
1. Run `python scripts/set_powerbi_data_path.py` once (writes the absolute path of `data/` into the `DataFolder` parameter).
2. Open the `.pbip` in Power BI Desktop, click **Refresh**, confirm no errors, then **File > Save as** `.pbix` if you want a single file.
3. Check the five KPI cards (3,900 / $233,081 / $59.76 / 3.75 / 1,053), test the slicers, and capture screenshots over `screenshots/`.
Model: `customer_data` (cleaned CSV, holds the five measures), `customer_segments` (LFM CSV, 1:1 on `customer_id`, duplicate amount/frequency columns hidden so revenue can only use `customer_data[purchase_amount_usd]`), `kpi_registry` (no relationship). To use MySQL instead of CSV, see `powerbi/KPI_Cards_Setup.md`.
Fixes versus the old PBIX: PostgreSQL source and `purchase_amount` replaced; the `category = Accessories` filter (which was baked into 11 visuals, including every slicer) is gone; charts that summed `customer_id` now use `Total Customers`; age charts use the six `age_group` bands; "Sales by ..." titles renamed; LFM segment charts added; KPI IDs added.
**Status:** the project is validated against Microsoft's PBIR/semantic-model JSON schemas and by the automated model tests, but it was generated without Power BI Desktop, so the first open/refresh in Desktop is the one remaining manual verification. `screenshots/dashboard_reference_*.png` are reference renders computed from the dashboard definition, not Desktop captures.

## Key analysis outputs
- Total recorded purchase amount in the supplied data: **$233,081** across **3,900 customers** (average purchase **$59.76**).
- Tie-safe LFM quintile scoring (`rank(method="average", pct=True)`) assigns identical `previous_purchases` (L bands: 1–10, 11–20, 21–30, 31–40, 41–50) and `purchase_amount_usd` (M bands: 20–34, 35–51, 52–67, 68–84, 85–100) values to the same score.
- LFM segment distribution: **Potential Loyalists** 1,734 ($103,287 / 44.31%), **Loyal** 795 ($58,890 / 25.27%), **Needs Attention** 795 ($37,395 / 16.04%), **Low Engagement** 302 ($10,293 / 4.42%), and **Champions** 274 ($23,216 / 9.96%).
- Category, season, age-group, purchase amount and segment charts are generated by the notebook.
- Interpret the results descriptively; near-zero correlations and sample-data characteristics do not support causal claims.


## Validation
The notebook asserts source shape (3,900 × 18), unique customer IDs, zero missing ratings after imputation, non-null engineered categories, valid frequency scores, tie-safe L and M quintile scoring (each distinct `previous_purchases` and `purchase_amount_usd` value maps to exactly one score), five segment labels, matching customer IDs, and the expected total purchase amount ($233,081). `python testing/run_all_tests.py` additionally runs the notebook end to end, 24 Power BI project checks and 14 MySQL checks (executed on MySQL 8.0.46).

## Limitations and assumptions
- Dataset has one row per customer and no purchase date or transaction history.
- `Frequency of Purchases` is a categorical field, not an observed transaction count. `"Bi-Weekly"` is scored 4 (interpreted as every two weeks, same as `"Fortnightly"`); because `"Bi-Weekly"` can mean either twice a week or every two weeks in English, this mapping is an explicit assumption.
- Segment thresholds are heuristic and need business validation.
- The notebook was verified on `pandas 3.0.2` and `3.0.3`; if running on `pandas 2.x`, re-run the validation cell to confirm identical behaviour.
- MySQL and Power BI integration require local configuration and Power BI Desktop; SQL scripts and the loader were executed on MySQL 8.0.46; the Power BI refresh must be verified once in Power BI Desktop.
