#!/usr/bin/env python3
"""Create the MySQL schema from sql/database_setup.sql and load both CSVs in
foreign-key-safe order, then verify row counts, KPI values and the KPI registry.

Required environment variables: MYSQL_USER, MYSQL_PASSWORD.
Optional: MYSQL_HOST (default localhost), MYSQL_PORT (default 3306),
          MYSQL_DATABASE (default retail_customer_intelligence).

What it does (in order):
  1. CREATE DATABASE IF NOT EXISTS <MYSQL_DATABASE>
  2. Runs sql/database_setup.sql (single source of truth for the schema). This DROPS
     and recreates customer_segments, customer_data and kpi_registry in that database
     (children first) and seeds kpi_registry with KPI-001..KPI-005.
  3. Loads customer_data FIRST (cleaned_customer_data.csv), then customer_segments
     (customer_lfm_segmentation.csv) because of the foreign key.
  4. Verifies: row counts, primary/foreign keys, the five KPI values against
     kpi_registry.expected_value, and kpi_registry against data/kpi_registry.csv.

Other tables and databases are never modified.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy.engine import URL

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
SETUP_SQL = ROOT / "sql" / "database_setup.sql"
DB_NAME = os.getenv("MYSQL_DATABASE", "retail_customer_intelligence")

CUSTOMER_COLUMNS = [
    "customer_id", "age", "gender", "item_purchased", "category",
    "purchase_amount_usd", "location", "size", "color", "season",
    "review_rating", "subscription_status", "shipping_type", "discount_applied",
    "previous_purchases", "payment_method", "frequency_of_purchases",
    "rating_imputed", "age_group", "spending_category", "rating_category",
    "loyalty_category", "discount_flag", "subscription_flag",
]
SEGMENT_COLUMNS = [
    "customer_id", "previous_purchases", "purchase_amount_usd",
    "frequency_of_purchases", "L_Score", "F_Score", "M_Score",
    "LFM_Score", "Customer_Segment",
]
REGISTRY_COLUMNS = [
    "kpi_id", "kpi_name", "description", "calculation_formula", "dax_formula",
    "data_source", "expected_value", "unit",
]

# SQL used to compute each KPI live from the loaded tables.
KPI_SQL = {
    "KPI-001": "SELECT COUNT(DISTINCT customer_id) FROM customer_data",
    "KPI-002": "SELECT SUM(purchase_amount_usd) FROM customer_data",
    "KPI-003": "SELECT AVG(purchase_amount_usd) FROM customer_data",
    "KPI-004": "SELECT AVG(review_rating) FROM customer_data",
    "KPI-005": "SELECT COUNT(DISTINCT customer_id) FROM customer_data WHERE subscription_status = 'Yes'",
}


def fail(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


def split_sql(script: str) -> list[str]:
    """Split a SQL script on ';' while respecting '...' strings and -- comments."""
    statements, buf = [], []
    in_str = False
    i, n = 0, len(script)
    while i < n:
        ch = script[i]
        if in_str:
            buf.append(ch)
            if ch == "'":
                if i + 1 < n and script[i + 1] == "'":      # escaped quote ''
                    buf.append("'")
                    i += 1
                else:
                    in_str = False
        elif ch == "'":
            in_str = True
            buf.append(ch)
        elif ch == "-" and script.startswith("--", i):      # line comment
            while i < n and script[i] != "\n":
                i += 1
            continue
        elif ch == ";":
            stmt = "".join(buf).strip()
            if stmt:
                statements.append(stmt)
            buf = []
        else:
            buf.append(ch)
        i += 1
    tail = "".join(buf).strip()
    if tail:
        statements.append(tail)
    return statements


def read_csvs():
    customer_path = DATA / "cleaned_customer_data.csv"
    segment_path = DATA / "customer_lfm_segmentation.csv"
    registry_path = DATA / "kpi_registry.csv"
    for p in (customer_path, segment_path, registry_path):
        if not p.exists():
            fail(f"{p.name} is missing. Run the notebook first or restore the file in data/.")
    customers = pd.read_csv(customer_path)
    segments = pd.read_csv(segment_path)
    registry = pd.read_csv(registry_path)
    if list(customers.columns) != CUSTOMER_COLUMNS:
        fail(f"cleaned_customer_data.csv columns do not match the expected schema. Found: {list(customers.columns)}")
    if list(segments.columns) != SEGMENT_COLUMNS:
        fail(f"customer_lfm_segmentation.csv columns do not match the expected schema. Found: {list(segments.columns)}")
    if list(registry.columns) != REGISTRY_COLUMNS:
        fail(f"kpi_registry.csv columns do not match the expected schema. Found: {list(registry.columns)}")
    if customers.customer_id.duplicated().any() or segments.customer_id.duplicated().any():
        fail("Duplicate customer_id detected in one of the CSV files.")
    if set(customers.customer_id) != set(segments.customer_id):
        fail("The customer_id sets in the two CSV files do not match.")
    return customers, segments, registry


def main() -> None:
    user = os.getenv("MYSQL_USER")
    password = os.getenv("MYSQL_PASSWORD")
    if not user or password is None:
        fail("Set MYSQL_USER and MYSQL_PASSWORD environment variables before running.")
    if not SETUP_SQL.exists():
        fail(f"{SETUP_SQL} not found.")

    customers, segments, registry_csv = read_csvs()

    host = os.getenv("MYSQL_HOST", "localhost")
    port = int(os.getenv("MYSQL_PORT", "3306"))
    base = dict(drivername="mysql+pymysql", username=user, password=password,
                host=host, port=port, query={"charset": "utf8mb4"})

    server_engine = create_engine(URL.create(**base), pool_pre_ping=True)
    try:
        with server_engine.connect() as conn:
            conn.exec_driver_sql(
                f"CREATE DATABASE IF NOT EXISTS `{DB_NAME}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
            conn.commit()
    except Exception as exc:
        fail(f"Could not connect/create database. Check that MySQL is running and the credentials are correct. Details: {exc}")
    finally:
        server_engine.dispose()

    engine = create_engine(URL.create(database=DB_NAME, **base), pool_pre_ping=True)
    try:
        # --- 1) schema + KPI registry from the single SQL source of truth -------------
        statements = [s for s in split_sql(SETUP_SQL.read_text(encoding="utf-8"))
                      if not s.upper().startswith(("CREATE DATABASE", "USE "))]
        with engine.connect() as conn:
            for stmt in statements:
                conn.exec_driver_sql(stmt)
            conn.commit()

        # --- 2) data load, parent first (foreign key) ---------------------------------
        with engine.begin() as conn:
            customers.to_sql("customer_data", conn, if_exists="append", index=False, chunksize=500, method="multi")
            segments.to_sql("customer_segments", conn, if_exists="append", index=False, chunksize=500, method="multi")

        # --- 3) verification ----------------------------------------------------------
        with engine.connect() as conn:
            n_cust = conn.exec_driver_sql("SELECT COUNT(*) FROM customer_data").scalar()
            n_seg = conn.exec_driver_sql("SELECT COUNT(*) FROM customer_segments").scalar()
            orphans = conn.exec_driver_sql(
                "SELECT COUNT(*) FROM customer_segments s LEFT JOIN customer_data c USING (customer_id) "
                "WHERE c.customer_id IS NULL").scalar()
            if n_cust != 3900 or n_seg != 3900 or orphans != 0:
                raise RuntimeError(f"Row-count check failed: customers={n_cust}, segments={n_seg}, orphans={orphans}")

            reg = pd.read_sql("SELECT * FROM kpi_registry ORDER BY kpi_id", conn)
            reg["expected_value"] = reg["expected_value"].astype(float)
            csv_sorted = registry_csv.sort_values("kpi_id").reset_index(drop=True)
            csv_sorted["expected_value"] = csv_sorted["expected_value"].astype(float)
            if not reg[REGISTRY_COLUMNS].equals(csv_sorted[REGISTRY_COLUMNS]):
                raise RuntimeError("kpi_registry table differs from data/kpi_registry.csv. Re-export the CSV from the SQL seed.")

            print("LOAD SUCCESS")
            print(f"Database: {DB_NAME}")
            print(f"customer_data rows:     {n_cust}")
            print(f"customer_segments rows: {n_seg}")
            print(f"kpi_registry rows:      {len(reg)}")
            print("\nKPI verification (live value vs registry expected value):")
            all_ok = True
            for row in reg.itertuples():
                live = float(conn.exec_driver_sql(KPI_SQL[row.kpi_id]).scalar())
                ok = round(live, 2) == round(float(row.expected_value), 2)
                all_ok &= ok
                print(f"  {row.kpi_id}  {row.kpi_name:<30} live={live:>12,.2f}  expected={row.expected_value:>12,.2f}  {'PASS' if ok else 'FAIL'}")
            if not all_ok:
                raise RuntimeError("One or more KPI values do not match kpi_registry.expected_value")
    except SystemExit:
        raise
    except Exception as exc:
        fail(f"Load failed. Details: {exc}")
    finally:
        engine.dispose()


if __name__ == "__main__":
    main()
