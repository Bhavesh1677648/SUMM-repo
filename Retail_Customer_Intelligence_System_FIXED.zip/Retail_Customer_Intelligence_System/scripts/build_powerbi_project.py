#!/usr/bin/env python3
"""Generate the Power BI Project (PBIP) for the Retail Customer Intelligence dashboard.

Output (text-based, git-friendly, opens directly in Power BI Desktop):
  powerbi/Retail_Customer_Intelligence.pbip
  powerbi/Retail_Customer_Intelligence.SemanticModel/   TMDL data model
  powerbi/Retail_Customer_Intelligence.Report/          PBIR report (page + visuals)

KPI IDs, names and descriptions are read from data/kpi_registry.csv, the same rows that
sql/database_setup.sql seeds into the MySQL kpi_registry table, so the dashboard and the
database can never disagree. Re-run this script after changing the registry or layout:

    python scripts/build_powerbi_project.py
"""
from __future__ import annotations

import csv
import json
import shutil
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PB = ROOT / "powerbi"
MODEL_DIR = PB / "Retail_Customer_Intelligence.SemanticModel"
REPORT_DIR = PB / "Retail_Customer_Intelligence.Report"
THEME_SRC = PB / "_theme" / "CY24SU10.json"

SCHEMA = "https://developer.microsoft.com/json-schemas/fabric/item"
V_REPORT, V_PAGE, V_VISUAL = "3.0.0", "2.0.0", "2.3.0"

NS = uuid.UUID("5b1c8c9e-0f7a-4c63-9a64-2f1d6a0e7b11")
def guid(name: str) -> str:
    return str(uuid.uuid5(NS, name))

# --------------------------------------------------------------------------------------
# Palette (matches the original dashboard look)
# --------------------------------------------------------------------------------------
PINK, PURPLE, NAVY, TITLE, TEXT, WHITE = "#E566B8", "#8B2E9E", "#1A239E", "#7B1FA2", "#252423", "#FFFFFF"

# --------------------------------------------------------------------------------------
# Semantic model definition
# --------------------------------------------------------------------------------------
# (name, tmdl dataType, M type, formatString or None, hidden)
CUSTOMER_COLS = [
    ("customer_id", "int64", "Int64.Type", "0", False),
    ("age", "int64", "Int64.Type", "0", False),
    ("gender", "string", "type text", None, False),
    ("item_purchased", "string", "type text", None, False),
    ("category", "string", "type text", None, False),
    ("purchase_amount_usd", "decimal", "Currency.Type", "\\$#,0.00", False),
    ("location", "string", "type text", None, False),
    ("size", "string", "type text", None, False),
    ("color", "string", "type text", None, False),
    ("season", "string", "type text", None, False),
    ("review_rating", "double", "type number", "0.0", False),
    ("subscription_status", "string", "type text", None, False),
    ("shipping_type", "string", "type text", None, False),
    ("discount_applied", "string", "type text", None, False),
    ("previous_purchases", "int64", "Int64.Type", "0", False),
    ("payment_method", "string", "type text", None, False),
    ("frequency_of_purchases", "string", "type text", None, False),
    ("rating_imputed", "int64", "Int64.Type", "0", False),
    ("age_group", "string", "type text", None, False),
    ("spending_category", "string", "type text", None, False),
    ("rating_category", "string", "type text", None, False),
    ("loyalty_category", "string", "type text", None, False),
    ("discount_flag", "int64", "Int64.Type", "0", False),
    ("subscription_flag", "int64", "Int64.Type", "0", False),
]
# customer_segments duplicates three customer_data columns. They are hidden so that
# revenue can only ever be bound to customer_data[purchase_amount_usd].
SEGMENT_COLS = [
    ("customer_id", "int64", "Int64.Type", "0", False),
    ("previous_purchases", "int64", "Int64.Type", "0", True),
    ("purchase_amount_usd", "decimal", "Currency.Type", "\\$#,0.00", True),
    ("frequency_of_purchases", "string", "type text", None, True),
    ("L_Score", "int64", "Int64.Type", "0", False),
    ("F_Score", "int64", "Int64.Type", "0", False),
    ("M_Score", "int64", "Int64.Type", "0", False),
    ("LFM_Score", "int64", "Int64.Type", "0", False),
    ("Customer_Segment", "string", "type text", None, False),
]
REGISTRY_COLS = [
    ("kpi_id", "string", "type text", None, False),
    ("kpi_name", "string", "type text", None, False),
    ("description", "string", "type text", None, False),
    ("calculation_formula", "string", "type text", None, False),
    ("dax_formula", "string", "type text", None, False),
    ("data_source", "string", "type text", None, False),
    ("expected_value", "double", "type number", "General Number", False),
    ("unit", "string", "type text", None, False),
]

# KPI measures. Names equal kpi_registry.kpi_name; the DAX text equals kpi_registry.dax_formula.
MEASURES = {
    "KPI-001": ("Total Customers", "DISTINCTCOUNT(customer_data[customer_id])", "#,0"),
    "KPI-002": ("Total Revenue", "SUM(customer_data[purchase_amount_usd])", "\\$#,0"),
    "KPI-003": ("Average Purchase Value", "AVERAGE(customer_data[purchase_amount_usd])", "\\$#,0.00"),
    "KPI-004": ("Average Review Rating", "AVERAGE(customer_data[review_rating])", "0.00"),
    "KPI-005": ("Customers With Subscription",
                'CALCULATE(DISTINCTCOUNT(customer_data[customer_id]), customer_data[subscription_status] = "Yes")', "#,0"),
}


def read_registry() -> list[dict]:
    with open(ROOT / "data" / "kpi_registry.csv", newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def m_table(csv_name: str, cols) -> str:
    types = ", ".join(f'{{"{n}", {m}}}' for n, _, m, _, _ in cols)
    return (
        "let\n"
        f'    Source = Csv.Document(File.Contents(Text.TrimEnd(DataFolder, "\\") & "\\{csv_name}"), '
        '[Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),\n'
        "    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),\n"
        f'    Typed = Table.TransformColumnTypes(Promoted, {{{types}}}, "en-US")\n'
        "in\n"
        "    Typed"
    )


def tmdl_columns(table: str, cols) -> str:
    out = []
    for name, dtype, _, fmt, hidden in cols:
        out.append(f"\tcolumn {name}")
        out.append(f"\t\tdataType: {dtype}")
        if hidden:
            out.append("\t\tisHidden")
        if fmt:
            out.append(f"\t\tformatString: {fmt}")
        out.append(f"\t\tlineageTag: {guid(table + '.' + name)}")
        out.append("\t\tsummarizeBy: none")
        out.append(f"\t\tsourceColumn: {name}")
        out.append("")
        out.append("\t\tannotation SummarizationSetBy = Automatic")
        out.append("")
    return "\n".join(out)


def tmdl_partition(table: str, csv_name: str, cols) -> str:
    body = "\n".join("\t\t\t\t" + line for line in m_table(csv_name, cols).split("\n"))
    return f"\tpartition {table} = m\n\t\tmode: import\n\t\tsource =\n{body}\n"


def write_model(registry: list[dict]) -> None:
    d = MODEL_DIR / "definition"
    (d / "tables").mkdir(parents=True, exist_ok=True)
    (MODEL_DIR / "definition.pbism").write_text(json.dumps({
        "$schema": f"{SCHEMA}/semanticModel/definitionProperties/1.0.0/schema.json",
        "version": "4.0", "settings": {}}, indent=2) + "\n", encoding="utf-8")
    (d / "database.tmdl").write_text("database\n\tcompatibilityLevel: 1600\n", encoding="utf-8")
    (d / "model.tmdl").write_text(
        "model Model\n\tculture: en-US\n\tdefaultPowerBIDataSourceVersion: powerBI_V3\n"
        "\tdiscourageImplicitMeasures\n\tsourceQueryCulture: en-US\n\tdataAccessOptions\n"
        "\t\tlegacyRedirects\n\t\treturnErrorValuesAsNull\n\n"
        "ref table customer_data\nref table customer_segments\nref table kpi_registry\nref expression DataFolder\n",
        encoding="utf-8")
    (d / "expressions.tmdl").write_text(
        "/// Folder that contains the CSV files (the project's data folder). Set it once with\n"
        "/// `python scripts/set_powerbi_data_path.py`, or edit it via Transform data > Manage Parameters.\n"
        'expression DataFolder = "C:\\Retail_Customer_Intelligence_System\\data" '
        'meta [IsParameterQuery = true, IsParameterQueryRequired = true, Type = "Text"]\n'
        f"\tlineageTag: {guid('expr.DataFolder')}\n"
        "\n\tannotation PBI_ResultType = Text\n", encoding="utf-8")
    (d / "relationships.tmdl").write_text(
        "/// One-to-one on customer_id: filtering a segment filters the matching customers (and vice versa).\n"
        "/// kpi_registry is metadata and is deliberately NOT related to customer data.\n"
        f"relationship {guid('rel.segments.customer')}\n"
        "\tfromColumn: customer_segments.customer_id\n\ttoColumn: customer_data.customer_id\n"
        "\tfromCardinality: one\n\ttoCardinality: one\n\tcrossFilteringBehavior: bothDirections\n",
        encoding="utf-8")

    # customer_data (holds the five KPI measures)
    lines = [f"table customer_data\n\tlineageTag: {guid('table.customer_data')}\n"]
    by_id = {r["kpi_id"]: r for r in registry}
    for kpi_id, (name, dax, fmt) in MEASURES.items():
        r = by_id[kpi_id]
        assert r["kpi_name"] == name and r["dax_formula"] == dax, f"registry/measure mismatch for {kpi_id}"
        lines.append(f"\t/// {kpi_id} | {name}: {r['description']}")
        lines.append(f"\tmeasure '{name}' = {dax}")
        lines.append(f"\t\tformatString: {fmt}")
        lines.append(f"\t\tdisplayFolder: KPIs")
        lines.append(f"\t\tlineageTag: {guid('measure.' + kpi_id)}")
        lines.append("")
    lines.append(tmdl_columns("customer_data", CUSTOMER_COLS))
    lines.append(tmdl_partition("customer_data", "cleaned_customer_data.csv", CUSTOMER_COLS))
    lines.append("\tannotation PBI_ResultType = Table\n")
    (d / "tables" / "customer_data.tmdl").write_text("\n".join(lines), encoding="utf-8")

    seg = [f"table customer_segments\n\tlineageTag: {guid('table.customer_segments')}\n",
           tmdl_columns("customer_segments", SEGMENT_COLS),
           tmdl_partition("customer_segments", "customer_lfm_segmentation.csv", SEGMENT_COLS),
           "\tannotation PBI_ResultType = Table\n"]
    (d / "tables" / "customer_segments.tmdl").write_text("\n".join(seg), encoding="utf-8")

    reg = [f"table kpi_registry\n\tlineageTag: {guid('table.kpi_registry')}\n",
           tmdl_columns("kpi_registry", REGISTRY_COLS),
           tmdl_partition("kpi_registry", "kpi_registry.csv", REGISTRY_COLS),
           "\tannotation PBI_ResultType = Table\n"]
    (d / "tables" / "kpi_registry.tmdl").write_text("\n".join(reg), encoding="utf-8")


# --------------------------------------------------------------------------------------
# Report (PBIR)
# --------------------------------------------------------------------------------------
def lit(v: str) -> dict:
    return {"expr": {"Literal": {"Value": v}}}

def s(text: str) -> dict:       # string literal
    return lit("'" + text.replace("'", "''") + "'")

def num(n) -> dict:             # double literal
    return lit(f"{n}D")

def boolean(b: bool) -> dict:
    return lit("true" if b else "false")

def color(hexv: str) -> dict:
    return {"solid": {"color": {"expr": {"Literal": {"Value": f"'{hexv}'"}}}}}

def col(entity: str, prop: str) -> dict:
    return {"Column": {"Expression": {"SourceRef": {"Entity": entity}}, "Property": prop}}

def mea(entity: str, prop: str) -> dict:
    return {"Measure": {"Expression": {"SourceRef": {"Entity": entity}}, "Property": prop}}

def proj(field: dict, active: bool = False) -> dict:
    kind = "Column" if "Column" in field else "Measure"
    ent = field[kind]["Expression"]["SourceRef"]["Entity"]
    prop = field[kind]["Property"]
    p = {"field": field, "queryRef": f"{ent}.{prop}", "nativeQueryRef": prop}
    if active:
        p["active"] = True
    return p


class Page:
    def __init__(self):
        self.visuals: list[tuple[str, dict]] = []
        self.z = 0

    def add(self, name, x, y, w, h, visual, tab=True):
        self.z += 1000
        pos = {"x": x, "y": y, "z": self.z, "height": h, "width": w}
        if tab:
            pos["tabOrder"] = self.z
        self.visuals.append((name, {
            "$schema": f"{SCHEMA}/report/definition/visualContainer/{V_VISUAL}/schema.json",
            "name": name, "position": pos, "visual": visual}))


def title_obj(text, size=12, fc=TITLE, align="left"):
    return [{"properties": {"show": boolean(True), "text": s(text), "fontColor": color(fc),
                            "fontSize": num(size), "bold": boolean(True), "alignment": s(align)}}]

def card_box(border=PURPLE, radius=8):
    return {"background": [{"properties": {"show": boolean(True), "color": color(WHITE), "transparency": num(0)}}],
            "border": [{"properties": {"show": boolean(True), "color": color(border), "radius": num(radius)}}]}


def kpi_card(kpi_id, name, entity="customer_data"):
    return {"visualType": "card",
            "query": {"queryState": {"Values": {"projections": [proj(mea(entity, name))]}}},
            "objects": {
                "labels": [{"properties": {"color": color(PURPLE), "fontSize": num(32), "bold": boolean(True),
                                           "labelDisplayUnits": num(0), "fontFamily": s("Segoe UI Semibold")}}],
                "categoryLabels": [{"properties": {"show": boolean(False)}}]},
            "visualContainerObjects": {"title": title_obj(f"{kpi_id} | {name}", 10, TEXT, "center"), **card_box()},
            "drillFilterOtherVisuals": True}


def chart(kind, title, cat, val, sort_by_value=True, labels=True, extra_objects=None):
    sort_field = val if sort_by_value else cat
    q = {"queryState": {"Category": {"projections": [proj(cat, active=True)]},
                        "Y": {"projections": [proj(val)]}},
         "sortDefinition": {"sort": [{"field": sort_field,
                                      "direction": "Descending" if sort_by_value else "Ascending"}],
                            "isDefaultSort": True}}
    objects = {
        "dataPoint": [{"properties": {"fill": color(NAVY)}}],
        "legend": [{"properties": {"show": boolean(False)}}],
        "labels": [{"properties": {"show": boolean(labels), "fontSize": num(10), "labelDisplayUnits": num(0)}}],
        "categoryAxis": [{"properties": {"showAxisTitle": boolean(False), "fontSize": num(10)}}],
        "valueAxis": [{"properties": {"showAxisTitle": boolean(False), "fontSize": num(10)}}],
    }
    objects.update(extra_objects or {})
    return {"visualType": kind, "query": q, "objects": objects,
            "visualContainerObjects": {"title": title_obj(title), **card_box()}, "drillFilterOtherVisuals": True}


def donut(title, cat, val):
    q = {"queryState": {"Category": {"projections": [proj(cat, active=True)]}, "Y": {"projections": [proj(val)]}}}
    pts = []
    for member, hexv in (("No", PINK), ("Yes", NAVY)):
        pts.append({"properties": {"fill": color(hexv)}, "selector": {"data": [{"scopeId": {"Comparison": {
            "ComparisonKind": 0, "Left": cat, "Right": {"Literal": {"Value": f"'{member}'"}}}}}]}})
    return {"visualType": "donutChart", "query": q,
            "objects": {"labels": [{"properties": {"labelStyle": s("Category, percent of total"),
                                                   "bold": boolean(True), "fontSize": num(12)}}],
                        "legend": [{"properties": {"show": boolean(False)}}], "dataPoint": pts},
            "visualContainerObjects": {"title": title_obj(title), **card_box()}, "drillFilterOtherVisuals": True}


def slicer(title, field):
    return {"visualType": "slicer",
            "query": {"queryState": {"Values": {"projections": [proj(field, active=True)]}}},
            "objects": {"data": [{"properties": {"mode": s("Basic")}}],
                        "header": [{"properties": {"show": boolean(False)}}],
                        "items": [{"properties": {"fontSize": num(11)}}],
                        "selection": [{"properties": {"singleSelect": boolean(False), "selectAllCheckboxEnabled": boolean(False)}}]},
            "visualContainerObjects": {"title": title_obj(title, 12, TEXT),
                                       "background": [{"properties": {"show": boolean(False)}}]},
            "drillFilterOtherVisuals": True}


def rect(fill_hex=None, outline_hex=None, rounded=False, transparent_fill=False):
    obj = {"shape": [{"properties": {"tileShape": s("rectangleRounded" if rounded else "rectangle")}}],
           "rotation": [{"properties": {"shapeAngle": lit("0L")}}]}
    if rounded:
        obj["shape"][0]["properties"]["rectangleRoundedCurve"] = lit("12L")
    if fill_hex:
        obj["fill"] = [{"properties": {"fillColor": color(fill_hex), "transparency": num(0)}, "selector": {"id": "default"}}]
    if transparent_fill:
        obj["fill"] = [{"properties": {"fillColor": color(WHITE), "transparency": num(100)}, "selector": {"id": "default"}}]
    if outline_hex:
        obj["outline"] = [{"properties": {"show": boolean(True), "lineColor": color(outline_hex), "weight": num(1.5)}}]
    else:
        obj["outline"] = [{"properties": {"show": boolean(False)}}]
    return {"visualType": "shape", "objects": obj, "drillFilterOtherVisuals": True}


def textbox(text, size="34pt"):
    return {"visualType": "textbox",
            "objects": {"general": [{"properties": {"paragraphs": [{"textRuns": [{"value": text, "textStyle": {
                "fontFamily": "Segoe UI Semibold", "fontSize": size, "fontWeight": "bold", "color": TEXT}}],
                "horizontalTextAlignment": "center"}]}}]},
            "visualContainerObjects": {"background": [{"properties": {"show": boolean(False)}}]},
            "drillFilterOtherVisuals": True}


def registry_table(fields):
    return {"visualType": "tableEx",
            "query": {"queryState": {"Values": {"projections": [proj(col("kpi_registry", f)) for f in fields]}},
                      "sortDefinition": {"sort": [{"field": col("kpi_registry", "kpi_id"), "direction": "Ascending"}],
                                         "isDefaultSort": True}},
            "objects": {"grid": [{"properties": {"textSize": num(10), "rowPadding": num(2)}}],
                        "columnHeaders": [{"properties": {"fontSize": num(10), "bold": boolean(True),
                                                          "fontColor": color(WHITE), "backColor": color(PURPLE)}}]},
            "visualContainerObjects": {"title": title_obj("KPI Registry (kpi_registry table: IDs, formulas and data sources)"),
                                       **card_box()},
            "drillFilterOtherVisuals": True}


def write_report(registry: list[dict]) -> None:
    if REPORT_DIR.exists():
        shutil.rmtree(REPORT_DIR)
    defn = REPORT_DIR / "definition"
    page_name = "customer_behavior_dashboard"
    pdir = defn / "pages" / page_name
    pdir.mkdir(parents=True)

    (REPORT_DIR / "definition.pbir").write_text(json.dumps({
        "$schema": f"{SCHEMA}/report/definitionProperties/2.0.0/schema.json", "version": "4.0",
        "datasetReference": {"byPath": {"path": "../Retail_Customer_Intelligence.SemanticModel"}}}, indent=2) + "\n", encoding="utf-8")
    (defn / "version.json").write_text(json.dumps({
        "$schema": f"{SCHEMA}/report/definition/versionMetadata/1.0.0/schema.json", "version": "2.0.0"}, indent=2) + "\n", encoding="utf-8")
    (defn / "report.json").write_text(json.dumps({
        "$schema": f"{SCHEMA}/report/definition/report/{V_REPORT}/schema.json",
        "themeCollection": {"baseTheme": {"name": "CY24SU10", "type": "SharedResources",
                                          "reportVersionAtImport": {"visual": "2.3.0", "report": "3.0.0", "page": "2.0.0"}}},
        "resourcePackages": [{"name": "SharedResources", "type": "SharedResources",
                              "items": [{"name": "CY24SU10", "path": "BaseThemes/CY24SU10.json", "type": "BaseTheme"}]}],
        "settings": {"allowChangeFilterTypes": True, "defaultDrillFilterOtherVisuals": True,
                     "useStylableVisualContainerHeader": True, "exportDataMode": "AllowSummarized"}}, indent=2) + "\n", encoding="utf-8")
    (defn / "pages" / "pages.json").write_text(json.dumps({
        "$schema": f"{SCHEMA}/report/definition/pagesMetadata/1.0.0/schema.json",
        "pageOrder": [page_name], "activePageName": page_name}, indent=2) + "\n", encoding="utf-8")

    W, H = 1500, 940
    (pdir / "page.json").write_text(json.dumps({
        "$schema": f"{SCHEMA}/report/definition/page/{V_PAGE}/schema.json", "name": page_name,
        "displayName": "Customer Behavior Dashboard", "displayOption": "FitToPage", "height": H, "width": W}, indent=2) + "\n", encoding="utf-8")

    pg = Page()
    CD, CS = "customer_data", "customer_segments"
    # --- decoration -------------------------------------------------------------------
    pg.add("bg_header", 0, 0, W, 92, rect(fill_hex=PINK), tab=False)
    pg.add("title", 0, 14, W, 66, textbox("Customer Behavior Dashboard"), tab=False)
    pg.add("bg_filters", 8, 100, 196, 832, rect(outline_hex=PURPLE, rounded=True, transparent_fill=True), tab=False)

    # --- slicers (left panel) ---------------------------------------------------------
    y = 108
    for name, label, field, h in [
        ("slicer_subscription", "Subscription Status", col(CD, "subscription_status"), 82),
        ("slicer_gender", "Gender", col(CD, "gender"), 82),
        ("slicer_category", "Category", col(CD, "category"), 126),
        ("slicer_age_group", "Age Group", col(CD, "age_group"), 172),
        ("slicer_segment", "LFM Customer Segment", col(CS, "Customer_Segment"), 148),
        ("slicer_shipping", "Shipping Type", col(CD, "shipping_type"), 172),
    ]:
        pg.add(name, 16, y, 180, h, slicer(label, field))
        y += h + 6

    # --- KPI cards: ID is in each card title ------------------------------------------
    cw, gap, x0 = 242, 15, 216
    for i, r in enumerate(registry):
        pg.add(r['kpi_id'].lower().replace('-', '_'), x0 + i * (cw + gap), 104, cw, 118,
               kpi_card(r["kpi_id"], r["kpi_name"]))

    # --- chart row 1 ------------------------------------------------------------------
    rx, rw, rg, rh = 216, 309, 11.3, 250
    r1 = 234
    pg.add("donut_subscription", rx, r1, rw, rh, donut("% of Customers by Subscription Status", col(CD, "subscription_status"), mea(CD, "Total Customers")))
    pg.add("col_revenue_category", rx + (rw + rg), r1, rw, rh, chart("clusteredColumnChart", "Revenue by Category", col(CD, "category"), mea(CD, "Total Revenue")))
    pg.add("col_customers_category", rx + 2 * (rw + rg), r1, rw, rh, chart("clusteredColumnChart", "Customers by Category", col(CD, "category"), mea(CD, "Total Customers")))
    pg.add("bar_customers_segment", rx + 3 * (rw + rg), r1, rw, rh, chart("clusteredBarChart", "Customers by LFM Segment", col(CS, "Customer_Segment"), mea(CD, "Total Customers")))
    # --- chart row 2 ------------------------------------------------------------------
    r2, bw = r1 + rh + 10, 412
    pg.add("bar_revenue_age", rx, r2, bw, rh, chart("clusteredBarChart", "Revenue by Age Group", col(CD, "age_group"), mea(CD, "Total Revenue"), sort_by_value=False))
    pg.add("bar_customers_age", rx + bw + 17, r2, bw, rh, chart("clusteredBarChart", "Customers by Age Group", col(CD, "age_group"), mea(CD, "Total Customers"), sort_by_value=False))
    pg.add("bar_revenue_segment", rx + 2 * (bw + 17), r2, bw, rh, chart("clusteredBarChart", "Revenue by LFM Segment", col(CS, "Customer_Segment"), mea(CD, "Total Revenue")))
    # --- KPI registry table -----------------------------------------------------------
    r3 = r2 + rh + 10
    pg.add("table_kpi_registry", rx, r3, 1268, H - r3 - 8, registry_table(
        ["kpi_id", "kpi_name", "calculation_formula", "data_source", "description"]))

    for name, doc in pg.visuals:
        vdir = pdir / "visuals" / name
        vdir.mkdir(parents=True)
        (vdir / "visual.json").write_text(json.dumps(doc, indent=2) + "\n", encoding="utf-8")

    theme_dst = REPORT_DIR / "StaticResources" / "SharedResources" / "BaseThemes"
    theme_dst.mkdir(parents=True)
    shutil.copy(THEME_SRC, theme_dst / "CY24SU10.json")


def write_pbip() -> None:
    (PB / "Retail_Customer_Intelligence.pbip").write_text(json.dumps({
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/pbip/pbipProperties/1.0.0/schema.json",
        "version": "1.0", "artifacts": [{"report": {"path": "Retail_Customer_Intelligence.Report"}}],
        "settings": {"enableAutoRecovery": True}}, indent=2) + "\n", encoding="utf-8")
    (PB / ".gitignore").write_text("**/.pbi/localSettings.json\n**/.pbi/cache.abf\n", encoding="utf-8")


def main() -> None:
    registry = read_registry()
    assert [r["kpi_id"] for r in registry] == list(MEASURES), "kpi_registry.csv must list KPI-001..KPI-005 in order"
    if MODEL_DIR.exists():
        shutil.rmtree(MODEL_DIR)
    write_model(registry)
    write_report(registry)
    write_pbip()
    print("Generated:", PB / "Retail_Customer_Intelligence.pbip")


if __name__ == "__main__":
    main()
