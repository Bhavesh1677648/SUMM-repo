#!/usr/bin/env python3
"""Validate the checked-in CSV outputs without needing a running MySQL server."""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
clean = pd.read_csv(ROOT / "data" / "cleaned_customer_data.csv")
seg = pd.read_csv(ROOT / "data" / "customer_lfm_segmentation.csv")
reg = pd.read_csv(ROOT / "data" / "kpi_registry.csv")
full = clean.merge(seg[["customer_id"]], on="customer_id")
checks = {
    "customer rows": len(clean) == 3900,
    "unique customer IDs": clean.customer_id.is_unique,
    "no missing cleaned values": not clean.isna().any().any(),
    "segmentation rows": len(seg) == 3900,
    "unique segment IDs": seg.customer_id.is_unique,
    "matching customer IDs": set(clean.customer_id) == set(seg.customer_id),
    "revenue total": float(clean.purchase_amount_usd.sum()) == 233081.0,
    "average purchase": round(float(clean.purchase_amount_usd.mean()), 2) == 59.76,
    "average rating": round(float(clean.review_rating.mean()), 2) == 3.75,
    "subscribers = 1,053": int((clean.subscription_status == "Yes").sum()) == 1053,
    "age groups are the six bands": sorted(clean.age_group.unique()) == ["18-24", "25-34", "35-44", "45-54", "55-64", "65+"],
    "registry has KPI-001..KPI-005": list(reg.kpi_id) == [f"KPI-00{i}" for i in range(1, 6)],
    "registry has all required fields": all(c in reg.columns for c in ["kpi_id", "kpi_name", "description", "calculation_formula", "data_source"]),
    "avg purchase: per record == per customer": abs(clean.purchase_amount_usd.mean() - clean.groupby("customer_id").purchase_amount_usd.sum().mean()) < 1e-9,
    "valid LFM scores": seg[["L_Score", "F_Score", "M_Score"]].isin([1, 2, 3, 4, 5]).all().all(),
}
for label, passed in checks.items():
    print(f"{'PASS' if passed else 'FAIL'}: {label}")
if not all(checks.values()):
    raise SystemExit(1)
print("\nAll CSV validation checks passed.")
