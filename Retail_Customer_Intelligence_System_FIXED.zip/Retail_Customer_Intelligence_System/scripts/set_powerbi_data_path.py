#!/usr/bin/env python3
"""Point the Power BI project's DataFolder parameter at this project's data/ folder.

Run once after unzipping (or after moving the project):   python scripts/set_powerbi_data_path.py
Power BI Desktop cannot resolve relative paths in Power Query, so the absolute path is written
into powerbi/Retail_Customer_Intelligence.SemanticModel/definition/expressions.tmdl.
"""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
f = ROOT / "powerbi" / "Retail_Customer_Intelligence.SemanticModel" / "definition" / "expressions.tmdl"
data = str((ROOT / "data").resolve())
text = f.read_text(encoding="utf-8")
new, n = re.subn(r'(expression DataFolder = ")[^"]*(")', lambda m: m.group(1) + data + m.group(2), text)
if n != 1:
    raise SystemExit("DataFolder expression not found in expressions.tmdl")
f.write_text(new, encoding="utf-8")
print(f"DataFolder set to: {data}")
